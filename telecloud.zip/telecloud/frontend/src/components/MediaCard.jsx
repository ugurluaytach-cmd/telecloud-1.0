import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { BASE_URL } from '../api/client.js';
import { getVideoStatus } from '../api/videoApi.js';

const BASE = BASE_URL;

const DOC_ICON = {
  pdf: 'PDF', doc: 'DOC', docx: 'DOC', xls: 'XLS', xlsx: 'XLS',
  ppt: 'PPT', pptx: 'PPT', zip: 'ZIP', rar: 'RAR', '7z': '7Z',
  txt: 'TXT', md: 'MD', json: '{ }', csv: 'CSV',
};
const TYPE_COLOR = {
  PHOTO: '#6ea8d4',
  VIDEO: '#d4836e',
  AUDIO: '#6ed4a8',
  DOCUMENT: '#a89fd4',
};

const _thumbCache = new Map();
const _pendingThumbs = new Map();
let _active = 0;
const _MAX = 5;
const _queue = [];

function runNext() {
  const next = _queue.shift();
  if (next) next();
}

function fetchThumb(key, url) {
  if (_thumbCache.has(key)) return Promise.resolve(_thumbCache.get(key));
  if (_pendingThumbs.has(key)) return _pendingThumbs.get(key);

  const promise = new Promise(resolve => {
    const run = () => {
      _active++;
      fetch(url)
        .then(r => r.ok ? r.blob() : null)
        .then(blob => {
          if (!blob) return null;
          const objectUrl = URL.createObjectURL(blob);
          _thumbCache.set(key, objectUrl);
          return objectUrl;
        })
        .catch(() => null)
        .then(resolve)
        .finally(() => {
          _active--;
          _pendingThumbs.delete(key);
          runNext();
        });
    };

    if (_active < _MAX) run();
    else _queue.push(run);
  });

  _pendingThumbs.set(key, promise);
  return promise;
}

export const MediaCard = memo(function MediaCard({ item, token, onClick, style }) {
  const thumbKey = `${item.channel_id || 'me'}:${item.id}`;
  const needsThumb = item.media_type === 'PHOTO' || item.media_type === 'VIDEO';
  const cachedThumb = needsThumb ? _thumbCache.get(thumbKey) : null;

  const [src, setSrc] = useState(cachedThumb || null);
  const [loaded, setLoaded] = useState(!!cachedThumb);
  const [hover, setHover] = useState(false);
  const [failed, setFailed] = useState(false);
  const [videoStatus, setVideoStatus] = useState('unknown');
  const ref = useRef();
  const fetched = useRef(!!cachedThumb);

  useEffect(() => {
    const cached = _thumbCache.get(thumbKey);
    setSrc(cached || null);
    setLoaded(!!cached);
    setFailed(false);
    setVideoStatus('unknown');
    fetched.current = !!cached;
  }, [thumbKey]);

  useEffect(() => {
    if (!needsThumb || fetched.current || !token) return;
    const el = ref.current;
    if (!el) return;

    const obs = new IntersectionObserver(entries => {
      if (!entries[0].isIntersecting || fetched.current) return;
      fetched.current = true;
      obs.disconnect();

      const url = `${BASE}/thumbnail/${item.channel_id || 'me'}/${item.id}?token=${token}`;
      fetchThumb(thumbKey, url).then(objectUrl => {
        if (objectUrl) setSrc(objectUrl);
        else setFailed(true);
      });

      if (item.media_type === 'VIDEO') {
        getVideoStatus(item.channel_id || 'me', item.id, token)
          .then(d => setVideoStatus(d.status || 'none'))
          .catch(() => setVideoStatus('unknown'));
      }
    }, { rootMargin: '700px' });

    obs.observe(el);
    return () => obs.disconnect();
  }, [item.channel_id, item.id, needsThumb, thumbKey, token]);

  const meta = useMemo(() => {
    const ext = item.filename?.split('.').pop()?.toLowerCase() || '';
    const color = TYPE_COLOR[item.media_type] || '#888';
    const size = item.file_size > 0
      ? item.file_size > 1e6 ? `${(item.file_size / 1e6).toFixed(1)} MB`
      : `${Math.round(item.file_size / 1024)} KB` : null;
    const date = item.date
      ? new Date(item.date).toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' })
      : null;

    return { ext, color, size, date };
  }, [item.date, item.file_size, item.filename, item.media_type]);

  return (
    <div ref={ref}
      style={{
        ...s.card,
        transform: hover ? 'translateY(-2px)' : 'translateY(0)',
        boxShadow: hover ? '0 8px 24px rgba(0,0,0,0.5)' : '0 1px 4px rgba(0,0,0,0.3)',
        ...style,
      }}
      onClick={() => onClick(item)}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <div style={s.thumbWrap}>
        {!src && needsThumb && !failed && <div style={s.skeleton} className="shimmer" />}

        {src && (
          <img
            src={src}
            alt={item.filename}
            loading="lazy"
            decoding="async"
            draggable={false}
            style={{...s.thumb, opacity: loaded ? 1 : 0}}
            onLoad={() => setLoaded(true)}
          />
        )}

        {((item.media_type === 'DOCUMENT' || item.media_type === 'AUDIO') || failed) && (
          <div style={s.docThumb}>
            <span style={s.docEmoji}>{item.media_type === 'AUDIO' ? '♪' : (DOC_ICON[meta.ext] || 'FILE')}</span>
            <span style={{...s.extBadge, background: `${meta.color}22`, color: meta.color}}>
              {item.media_type === 'AUDIO' ? 'AUDIO' : (meta.ext || 'FILE').toUpperCase()}
            </span>
          </div>
        )}

        {item.media_type === 'VIDEO' && (
          <div style={{
            ...s.videoBadge,
            ...(videoStatus === 'ready' ? s.videoReady : {}),
            ...(videoStatus === 'downloading' ? s.videoLoading : {}),
          }}>
            <svg width="8" height="8" viewBox="0 0 24 24" fill="white"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            {videoStatus === 'ready' && <span style={s.videoBadgeText}>Hazır</span>}
            {videoStatus === 'downloading' && <span style={s.videoBadgeText}>Cache</span>}
          </div>
        )}

        <div style={{...s.hoverOverlay, opacity: hover ? 1 : 0}}>
          <div style={s.hoverCircle}>
            {item.media_type === 'VIDEO'
              ? <svg width="20" height="20" viewBox="0 0 24 24" fill="white"><polygon points="5 3 19 12 5 21 5 3"/></svg>
              : item.media_type === 'AUDIO'
              ? <span style={{fontSize: 20}}>♪</span>
              : <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>}
          </div>
        </div>
      </div>

      <div style={s.info}>
        <p style={s.fname} title={item.filename}>{item.filename}</p>
        <div style={s.meta}>
          {meta.date && <span style={s.chip}>{meta.date}</span>}
          {meta.size && <span style={s.chip}>{meta.size}</span>}
        </div>
      </div>
    </div>
  );
});

const s = {
  card:      { background:'var(--bg-raised)', border:'1px solid var(--border)', borderRadius:10, overflow:'hidden', cursor:'pointer', transition:'transform 0.2s, box-shadow 0.2s', animation:'fadeUp 0.3s both', contain:'layout paint style' },
  thumbWrap: { position:'relative', aspectRatio:'1/1', overflow:'hidden', background:'var(--bg-overlay)' },
  skeleton:  { position:'absolute', inset:0 },
  thumb:     { width:'100%', height:'100%', objectFit:'cover', display:'block', transition:'opacity 0.25s', willChange:'opacity' },
  docThumb:  { position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:8 },
  docEmoji:  { fontSize:24, fontFamily:'var(--font-display)', color:'var(--text-secondary)', fontWeight:600 },
  extBadge:  { fontSize:9, fontWeight:700, letterSpacing:'0.06em', padding:'2px 7px', borderRadius:99 },
  videoBadge:{ position:'absolute', bottom:7, left:7, background:'rgba(0,0,0,0.65)', borderRadius:99, padding:'3px 7px', display:'flex', alignItems:'center', gap:4 },
  videoReady:{ background:'rgba(74,158,111,0.86)' },
  videoLoading:{ background:'rgba(212,168,71,0.82)' },
  videoBadgeText:{ color:'#fff', fontSize:9, fontWeight:700 },
  hoverOverlay:{ position:'absolute', inset:0, background:'rgba(0,0,0,0.45)', display:'flex', alignItems:'center', justifyContent:'center', transition:'opacity 0.2s', pointerEvents:'none' },
  hoverCircle: { width:44, height:44, borderRadius:'50%', background:'rgba(255,255,255,0.15)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff' },
  info:  { padding:'8px 10px 10px' },
  fname: { fontSize:11, color:'var(--text-primary)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', margin:'0 0 4px', fontWeight:400 },
  meta:  { display:'flex', gap:4, flexWrap:'wrap', minHeight:17 },
  chip:  { fontSize:10, color:'var(--text-muted)', background:'var(--bg-overlay)', padding:'1px 5px', borderRadius:4 },
};
