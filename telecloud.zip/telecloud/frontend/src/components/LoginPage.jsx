import { useState } from 'react';
import { useAuth } from '../hooks/useAuth.jsx';
import { requestJson } from '../api/client.js';

export function LoginPage() {
  const { loginWithTelegram } = useAuth();
  const [step,    setStep]    = useState(1);
  const [phone,   setPhone]   = useState('');
  const [code,    setCode]    = useState('');
  const [error,   setError]   = useState('');
  const [loading, setLoading] = useState(false);

  const sendCode = async () => {
    if (!phone.trim()) return;
    setError(''); setLoading(true);
    try {
      await requestJson('/auth/send_code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: phone.trim() })
      });
      setStep(2);
    } catch(e) { setError(e.message); }
    finally { setLoading(false); }
  };

  const verify = async () => {
    if (!code.trim()) return;
    setError(''); setLoading(true);
    try {
      await loginWithTelegram(phone.trim(), code.trim());
    } catch(e) { setError(e.message); }
    finally { setLoading(false); }
  };

  return (
    <div style={s.page}>
      <div style={s.bg} />
      <div style={s.card}>
        <div style={s.logoWrap}>
          <div style={s.logoIcon}>☁</div>
          <p style={s.logoText}><span style={s.logoAccent}>tele</span>cloud</p>
          <p style={s.logoSub}>Kişisel medya arşiviniz</p>
        </div>

        <div style={s.steps}>
          <div style={{...s.step, ...(step >= 1 ? s.stepActive : {})}}>1</div>
          <div style={s.stepLine} />
          <div style={{...s.step, ...(step >= 2 ? s.stepActive : {})}}>2</div>
        </div>
        <p style={s.stepLabel}>{step === 1 ? 'Telefon numarası' : 'SMS doğrulama'}</p>

        {step === 1 ? (
          <div style={s.form}>
            <div style={s.inputWrap}>
              <span style={s.inputIcon}>📱</span>
              <input style={s.input} type="tel" value={phone}
                onChange={e => setPhone(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendCode()}
                placeholder="+90 555 123 4567" autoFocus />
            </div>
            {error && <p style={s.error}>{error}</p>}
            <button style={{...s.btn, opacity: loading ? 0.6 : 1}}
              onClick={sendCode} disabled={loading}>
              {loading ? <><span style={s.spin} /> Gönderiliyor...</> : 'SMS kodu gönder'}
            </button>
            <p style={s.hint}>Telegram hesabınıza doğrulama kodu gelecek</p>
          </div>
        ) : (
          <div style={s.form}>
            <p style={s.sentTo}>Kod gönderildi: <strong>{phone}</strong></p>
            <div style={s.inputWrap}>
              <span style={s.inputIcon}>🔐</span>
              <input style={{...s.input, letterSpacing: '0.2em', fontSize: 20, textAlign: 'center'}}
                type="text" value={code}
                onChange={e => setCode(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && verify()}
                placeholder="_ _ _ _ _" maxLength={6} autoFocus />
            </div>
            {error && <p style={s.error}>{error}</p>}
            <button style={{...s.btn, opacity: loading ? 0.6 : 1}}
              onClick={verify} disabled={loading}>
              {loading ? <><span style={s.spin} /> Doğrulanıyor...</> : 'Giriş yap'}
            </button>
            <button style={s.backBtn} onClick={() => { setStep(1); setCode(''); setError(''); }}>
              Telefonu değiştir
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

const s = {
  page:      { minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)', position: 'relative', overflow: 'hidden' },
  bg:        { position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 60% 60% at 50% 0%, rgba(212,168,71,0.06) 0%, transparent 70%)', pointerEvents: 'none' },
  card:      { position: 'relative', zIndex: 1, width: '100%', maxWidth: 380, background: 'var(--bg-raised)', border: '1px solid var(--border)', borderRadius: 20, padding: '36px 32px 32px', boxShadow: '0 8px 40px rgba(0,0,0,0.6)', animation: 'fadeUp 0.4s var(--ease-out) both' },
  logoWrap:  { textAlign: 'center', marginBottom: 28 },
  logoIcon:  { fontSize: 40, marginBottom: 8, display: 'block' },
  logoText:  { fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 600, color: 'var(--text-primary)', letterSpacing: 0, margin: '0 0 4px' },
  logoAccent:{ color: 'var(--accent)' },
  logoSub:   { fontSize: 12, color: 'var(--text-muted)', letterSpacing: '0.05em' },
  steps:     { display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginBottom: 8 },
  step:      { width: 28, height: 28, borderRadius: '50%', background: 'var(--bg-overlay)', border: '1px solid var(--border-mid)', color: 'var(--text-muted)', fontSize: 12, fontWeight: 600, display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.3s' },
  stepActive:{ background: 'var(--accent-dim)', borderColor: 'var(--accent)', color: 'var(--accent)' },
  stepLine:  { width: 40, height: 1, background: 'var(--border-mid)' },
  stepLabel: { textAlign: 'center', fontSize: 11, color: 'var(--text-muted)', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 24 },
  form:      { display: 'flex', flexDirection: 'column', gap: 12 },
  inputWrap: { display: 'flex', alignItems: 'center', gap: 10, background: 'var(--bg-overlay)', border: '1px solid var(--border-mid)', borderRadius: 10, padding: '11px 14px', transition: 'border-color 0.15s' },
  inputIcon: { fontSize: 16, flexShrink: 0 },
  input:     { flex: 1, background: 'none', border: 'none', outline: 'none', color: 'var(--text-primary)', fontSize: 14, fontFamily: 'var(--font-body)', fontWeight: 300 },
  error:     { fontSize: 12, color: '#e87070', background: 'rgba(192,80,80,0.1)', border: '1px solid rgba(192,80,80,0.2)', borderRadius: 8, padding: '8px 12px' },
  sentTo:    { fontSize: 13, color: 'var(--text-secondary)', textAlign: 'center' },
  btn:       { display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, background: 'var(--accent)', color: '#0a0a09', border: 'none', borderRadius: 10, padding: '12px', fontSize: 13, fontWeight: 500, cursor: 'pointer', fontFamily: 'var(--font-body)', transition: 'opacity 0.15s', marginTop: 4 },
  spin:      { width: 14, height: 14, border: '2px solid rgba(0,0,0,0.2)', borderTopColor: '#0a0a09', borderRadius: '50%', animation: 'spin 0.7s linear infinite', display: 'inline-block' },
  backBtn:   { background: 'none', border: 'none', color: 'var(--text-muted)', fontSize: 12, cursor: 'pointer', fontFamily: 'var(--font-body)', textAlign: 'center', padding: 4 },
  hint:      { fontSize: 11, color: 'var(--text-muted)', textAlign: 'center' },
};
