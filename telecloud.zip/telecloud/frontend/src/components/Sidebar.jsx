import { useState } from 'react';

const NAV = [
  { id: 'all',   icon: '⊞', label: 'Tümü' },
  { id: 'photo', icon: '●', label: 'Fotoğraflar' },
  { id: 'video', icon: '▶', label: 'Videolar' },
  { id: 'audio', icon: '♪', label: 'Sesler' },
  { id: 'doc',   icon: '≡', label: 'Dosyalar' },
];

const FILTERS = {
  all: undefined,
  photo: 'PHOTO',
  video: 'VIDEO',
  audio: 'AUDIO',
  doc: 'DOCUMENT',
};

export function Sidebar({ channels, activeChannel, onChannelSelect, onNewChannel, filter, onFilterChange, storage, user }) {
  const [newName, setNewName] = useState('');
  const [adding, setAdding] = useState(false);
  const [creating, setCreating] = useState(false);

  const handleCreate = async () => {
    if (!newName.trim()) return;
    setCreating(true);
    try {
      await onNewChannel(newName.trim());
      setNewName('');
      setAdding(false);
    } finally {
      setCreating(false);
    }
  };

  const used = storage?.used_gb || 0;
  const limit = storage?.storage_limit_gb || 2;
  const pct = Math.min((used / limit) * 100, 100);

  return (
    <aside style={s.sidebar}>
      <div style={s.logo}>
        <span style={s.logoText}>
          <span style={s.logoAccent}>tele</span>cloud
        </span>
        {storage?.premium && <span style={s.premiumBadge}>PRO</span>}
      </div>

      {user && (
        <div style={s.userBox}>
          <div style={s.avatar}>{(user.name || '?')[0].toUpperCase()}</div>
          <div style={s.userInfo}>
            <p style={s.userName}>{user.name}</p>
            <p style={s.userPhone}>{user.phone}</p>
          </div>
        </div>
      )}

      <div style={s.divider} />

      <div style={s.section}>
        <p style={s.sectionLabel}>Medya türü</p>
        {NAV.map(n => {
          const filterVal = FILTERS[n.id];
          const active = filter === filterVal;
          return (
            <button key={n.id} style={{...s.navItem, ...(active ? s.navActive : {})}}
              onClick={() => onFilterChange(filterVal)}>
              <span style={s.navIcon}>{n.icon}</span>
              <span style={s.navLabel}>{n.label}</span>
              {active && <span style={s.navDot} />}
            </button>
          );
        })}
      </div>

      <div style={s.divider} />

      <div style={{...s.section, flex:1, overflow:'hidden', display:'flex', flexDirection:'column'}}>
        <div style={s.sectionHeader}>
          <p style={s.sectionLabel}>Depolar</p>
          <button style={s.addBtn} onClick={() => setAdding(a => !a)} title="Yeni depo">
            {adding ? '×' : '+'}
          </button>
        </div>

        {adding && (
          <div style={s.newBox}>
            <input style={s.newInput} placeholder="Depo adı..." value={newName}
              onChange={e => setNewName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleCreate()} autoFocus />
            <button style={s.createBtn} onClick={handleCreate} disabled={creating}>
              {creating ? '...' : 'Oluştur'}
            </button>
          </div>
        )}

        <div style={s.channelList}>
          {channels.map(ch => {
            const active = String(activeChannel) === String(ch.id);
            return (
              <button key={ch.id} style={{...s.channelItem, ...(active ? s.channelActive : {})}}
                onClick={() => onChannelSelect(String(ch.id))}>
                <span style={{...s.channelDot, background: active ? 'var(--accent)' : 'var(--border-mid)'}} />
                <span style={s.channelName}>{ch.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {storage && (
        <div style={s.storageBox}>
          <div style={s.storageHeader}>
            <span style={s.storageLabel}>Depolama</span>
            <span style={s.storageValue}>{storage.premium ? '∞' : `${limit} GB`}</span>
          </div>
          <div style={s.storageBar}>
            <div style={{...s.storageFill, width: `${pct}%`}} />
          </div>
          <p style={s.storageSub}>
            {storage.premium ? 'Premium · 4 GB tek dosya' : 'Standart · 2 GB tek dosya'}
          </p>
        </div>
      )}
    </aside>
  );
}

const s = {
  sidebar: {
    width: 'var(--sidebar-w)', background: 'var(--bg-raised)',
    borderRight: '1px solid var(--border)',
    display: 'flex', flexDirection: 'column',
    height: '100vh', flexShrink: 0,
  },
  logo: {
    padding: '20px 18px 16px',
    display: 'flex', alignItems: 'center', gap: 8,
  },
  logoText: {
    fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 600,
    letterSpacing: 0, color: 'var(--text-primary)',
  },
  logoAccent: { color: 'var(--accent)' },
  premiumBadge: {
    fontSize: 9, fontWeight: 700, letterSpacing: '0.1em',
    color: 'var(--accent)', background: 'var(--accent-dim)',
    border: '1px solid var(--accent-dark)',
    padding: '2px 6px', borderRadius: 99,
  },
  userBox: {
    display: 'flex', alignItems: 'center', gap: 10,
    padding: '0 18px 14px',
  },
  userInfo: { minWidth: 0 },
  avatar: {
    width: 32, height: 32, borderRadius: '50%',
    background: 'var(--accent-dim)', border: '1px solid var(--accent-dark)',
    color: 'var(--accent)', fontSize: 13, fontWeight: 600,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: 'var(--font-display)', flexShrink: 0,
  },
  userName:  { fontSize: 13, color: 'var(--text-primary)', fontWeight: 400, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' },
  userPhone: { fontSize: 11, color: 'var(--text-muted)', marginTop: 1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' },
  divider:   { height: 1, background: 'var(--border)', margin: '0 0' },
  section:   { padding: '12px 10px 8px' },
  sectionHeader: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 6px 8px' },
  sectionLabel: { fontSize: 10, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)' },
  navItem: {
    display: 'flex', alignItems: 'center', gap: 10,
    padding: '8px 10px', borderRadius: 'var(--r-sm)',
    background: 'none', border: 'none',
    color: 'var(--text-secondary)', fontSize: 13,
    cursor: 'pointer', width: '100%', position: 'relative',
    transition: 'all 0.15s',
  },
  navActive: { background: 'var(--bg-overlay)', color: 'var(--text-primary)' },
  navIcon:   { fontSize: 14, width: 16, textAlign: 'center', flexShrink: 0 },
  navLabel:  { flex: 1, textAlign: 'left', fontWeight: 400 },
  navDot: {
    width: 4, height: 4, borderRadius: '50%',
    background: 'var(--accent)', flexShrink: 0,
  },
  addBtn: {
    background: 'none', border: 'none',
    color: 'var(--text-muted)', fontSize: 18, lineHeight: 1,
    cursor: 'pointer', width: 22, height: 22,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    borderRadius: 4, transition: 'color 0.15s',
  },
  newBox:    { padding: '0 2px 8px', display: 'flex', flexDirection: 'column', gap: 6 },
  newInput:  {
    background: 'var(--bg-overlay)', border: '1px solid var(--border-mid)',
    borderRadius: 'var(--r-sm)', color: 'var(--text-primary)',
    padding: '7px 10px', fontSize: 12, outline: 'none', width: '100%',
  },
  createBtn: {
    background: 'var(--accent)', border: 'none', borderRadius: 'var(--r-sm)',
    color: '#0a0a09', padding: '6px', fontSize: 12, fontWeight: 500,
    cursor: 'pointer', fontFamily: 'var(--font-body)',
  },
  channelList: { flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 2 },
  channelItem: {
    display: 'flex', alignItems: 'center', gap: 8,
    padding: '7px 10px', borderRadius: 'var(--r-sm)',
    background: 'none', border: 'none',
    color: 'var(--text-secondary)', fontSize: 12,
    cursor: 'pointer', width: '100%', textAlign: 'left',
    transition: 'all 0.15s',
  },
  channelActive: { background: 'var(--bg-overlay)', color: 'var(--text-primary)' },
  channelDot:    { width: 6, height: 6, borderRadius: '50%', flexShrink: 0 },
  channelName:   { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  storageBox:    { padding: '14px 18px', borderTop: '1px solid var(--border)' },
  storageHeader: { display: 'flex', justifyContent: 'space-between', marginBottom: 8 },
  storageLabel:  { fontSize: 11, color: 'var(--text-muted)', fontWeight: 500 },
  storageValue:  { fontSize: 11, color: 'var(--accent)', fontWeight: 600 },
  storageBar:    { height: 3, background: 'var(--bg-overlay)', borderRadius: 99, overflow: 'hidden', marginBottom: 6 },
  storageFill:   { height: '100%', background: 'var(--accent)', borderRadius: 99, transition: 'width 0.6s var(--ease-out)' },
  storageSub:    { fontSize: 10, color: 'var(--text-muted)' },
};
