import { useCallback, useEffect, useRef, useState } from 'react';
import { BASE_URL } from '../api/client.js';
import { getVideoStatus, startVideoCache, videoPlayUrl } from '../api/videoApi.js';

const BASE = BASE_URL;

export function Viewer({ item, token, items, onClose, onNavigate }) {
  const [mediaSrc, setMediaSrc] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [showCtrl, setShowCtrl] = useState(true);
  const [buffered, setBuffered] = useState(0);
  const [dlState, setDlState] = useState('idle');
  const [vidStatus, setVidStatus] = useState('none');
  const [vidPct, setVidPct] = useState(0);
  const [vidError, setVidError] = useState('');

  const videoRef = useRef();
  const hideTimer = useRef();
  const pollTimer = useRef();
  const blobRef = useRef();

  const idx = items?.findIndex(
    i => i.id === item.id && String(i.channel_id) === String(item.channel_id)
  ) ?? -1;
  const cid = item.channel_id || 'me';
  const streamUrl = `${BASE}/stream/${cid}/${item.id}?token=${token}`;
  const downloadUrl = `${BASE}/download/${cid}/${item.id}?token=${token}`;
  const playUrl = videoPlayUrl(cid, item.id, token);

  const clearPolling = useCallback(() => {
    clearInterval(pollTimer.current);
    pollTimer.current = null;
  }, []);

  const startPolling = useCallback(() => {
    clearPolling();
    let misses = 0;

    pollTimer.current = setInterval(async () => {
      try {
        const d = await getVideoStatus(cid, item.id, token);
        misses = 0;

        if (d.status === 'ready') {
          clearPolling();
          setVidStatus('ready');
          setVidPct(100);
          setVidError('');
          setMediaSrc(playUrl);
        } else if (d.status === 'downloading') {
          setVidStatus('downloading');
          setVidPct(Number(d.progress || 0));
        }
      } catch {
        misses += 1;
        if (misses >= 3) {
          clearPolling();
          setVidStatus('error');
          setVidError('Video durumu okunamadı.');
        }
      }
    }, 1500);
  }, [cid, item.id, token, playUrl, clearPolling]);

  const startDownload = useCallback(async () => {
    setVidStatus('downloading');
    setVidPct(0);
    setVidError('');
    setMediaSrc(null);

    try {
      const d = await startVideoCache(cid, item.id, token);
      if (d.status === 'ready') {
        setVidStatus('ready');
        setVidPct(100);
        setMediaSrc(playUrl);
      } else {
        startPolling();
      }
    } catch {
      setVidStatus('error');
      setVidError('Video cache başlatılamadı.');
    }
  }, [cid, item.id, token, playUrl, startPolling]);

  useEffect(() => {
    setMediaSrc(null);
    setLoading(true);
    setError(null);
    setProgress(0);
    setDuration(0);
    setBuffered(0);
    setDlState('idle');
    setVidStatus('none');
    setVidPct(0);
    setVidError('');
    clearPolling();

    if (blobRef.current) {
      URL.revokeObjectURL(blobRef.current);
      blobRef.current = null;
    }

    if (item.media_type === 'PHOTO') {
      fetch(streamUrl)
        .then(r => r.ok ? r.blob() : Promise.reject(r.status))
        .then(blob => {
          const url = URL.createObjectURL(blob);
          blobRef.current = url;
          setMediaSrc(url);
          setLoading(false);
        })
        .catch(e => {
          setError(`Yüklenemedi: ${e}`);
          setLoading(false);
        });
    } else if (item.media_type === 'AUDIO') {
      setMediaSrc(streamUrl);
      setLoading(false);
    } else if (item.media_type === 'VIDEO') {
      setLoading(false);
      getVideoStatus(cid, item.id, token)
        .then(d => {
          if (d.status === 'ready') {
            setVidStatus('ready');
            setVidPct(100);
            setMediaSrc(playUrl);
          } else if (d.status === 'downloading') {
            setVidStatus('downloading');
            setVidPct(Number(d.progress || 0));
            startPolling();
          } else {
            startDownload();
          }
        })
        .catch(() => startDownload());
    } else {
      setLoading(false);
    }

    return () => {
      clearPolling();
      if (blobRef.current) {
        URL.revokeObjectURL(blobRef.current);
        blobRef.current = null;
      }
    };
  }, [item.id, item.channel_id, item.media_type, cid, token, streamUrl, playUrl, startDownload, startPolling, clearPolling]);

  useEffect(() => {
    const onKey = e => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onNavigate?.('next');
      if (e.key === 'ArrowLeft') onNavigate?.('prev');
      if (e.key === ' ' && (item.media_type === 'VIDEO' || item.media_type === 'AUDIO')) {
        e.preventDefault();
        videoRef.current?.paused ? videoRef.current.play() : videoRef.current?.pause();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [item.media_type, onClose, onNavigate]);

  const revealCtrl = () => {
    setShowCtrl(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => playing && setShowCtrl(false), 3000);
  };

  const onTimeUpdate = () => {
    const v = videoRef.current;
    if (!v) return;
    setProgress(v.currentTime);
    if (v.buffered.length > 0 && v.duration) {
      setBuffered(v.buffered.end(v.buffered.length - 1) / v.duration);
    }
  };

  const seek = e => {
    const bar = e.currentTarget;
    const pct = (e.clientX - bar.getBoundingClientRect().left) / bar.offsetWidth;
    if (videoRef.current && duration) videoRef.current.currentTime = pct * duration;
  };

  const fmtTime = seconds => {
    if (!seconds || Number.isNaN(seconds)) return '0:00';
    return `${Math.floor(seconds / 60)}:${Math.floor(seconds % 60).toString().padStart(2, '0')}`;
  };

  const fmtSize = item.file_size > 0
    ? item.file_size > 1e6 ? `${(item.file_size / 1e6).toFixed(1)} MB`
    : `${Math.round(item.file_size / 1024)} KB` : '';

  const handleDownload = async () => {
    setDlState('loading');
    try {
      if (window.electronAPI?.saveFile) {
        const result = await window.electronAPI.saveFile({
          url: downloadUrl, filename: item.filename, token,
        });
        if (result?.canceled) {
          setDlState('idle');
          return;
        }
        setDlState(result?.success ? 'done' : 'error');
      } else {
        const res = await fetch(downloadUrl);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = item.filename;
        a.click();
        URL.revokeObjectURL(url);
        setDlState('done');
      }
    } catch {
      setDlState('error');
    } finally {
      setTimeout(() => setDlState('idle'), 3000);
    }
  };

  const docLabel = () => {
    const ext = item.filename?.split('.').pop()?.toUpperCase() || 'FILE';
    return ext.length <= 5 ? ext : 'FILE';
  };

  return (
    <div style={s.backdrop} onClick={onClose}>
      <div style={s.header} onClick={e => e.stopPropagation()}>
        <div style={s.hLeft}>
          <button style={s.iconBtn} onClick={onClose} title="Kapat">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
          <div style={s.titleBox}>
            <p style={s.fname}>{item.filename}</p>
            {fmtSize && <p style={s.fmeta}>{fmtSize} · {item.media_type}</p>}
          </div>
        </div>
        <div style={s.hRight}>
          {items && idx >= 0 && <span style={s.counter}>{idx + 1} / {items.length}</span>}
          <button style={{
            ...s.dlBtn,
            ...(dlState === 'loading' ? {opacity:0.6,cursor:'not-allowed'} : {}),
            ...(dlState === 'done' ? {borderColor:'rgba(74,158,111,0.4)',color:'#4a9e6f'} : {}),
            ...(dlState === 'error' ? {borderColor:'rgba(192,80,80,0.4)',color:'#e87070'} : {}),
          }} onClick={handleDownload} disabled={dlState === 'loading'}>
            {dlState === 'loading' ? <span style={s.spinSm}/> :
             dlState === 'done' ? '✓' : dlState === 'error' ? '×' :
             <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
               <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
               <polyline points="7 10 12 15 17 10"/>
               <line x1="12" y1="15" x2="12" y2="3"/>
             </svg>}
            <span>{dlState === 'loading' ? 'İndiriliyor...' : dlState === 'done' ? 'İndirildi' : dlState === 'error' ? 'Hata' : 'İndir'}</span>
          </button>
        </div>
      </div>

      <div style={s.mediaArea} onClick={e => e.stopPropagation()} onMouseMove={revealCtrl}>
        {items && idx > 0 && (
          <button style={{...s.navBtn, left:16}} onClick={() => onNavigate('prev')} title="Önceki">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
        )}

        {loading && <div style={s.spinWrap}><div style={s.spinner}/></div>}
        {error && <div style={s.errorBox}><p style={s.errorIcon}>!</p><p>{error}</p></div>}

        {!loading && !error && item.media_type === 'PHOTO' && mediaSrc && (
          <img src={mediaSrc} alt={item.filename} style={s.photo} draggable={false}/>
        )}

        {!loading && !error && item.media_type === 'VIDEO' && (
          <div style={s.videoWrap}>
            {vidStatus === 'downloading' && (
              <div style={s.vidOverlay}>
                <div style={s.spinner}/>
                <p style={s.vidPctText}>{Math.max(0, Math.min(100, vidPct)).toFixed(0)}%</p>
                <div style={s.progressTrack}>
                  <div style={{...s.progressFill, width:`${Math.max(3, Math.min(100, vidPct))}%`}}/>
                </div>
                <p style={s.vidHint}>Video cache'e alınıyor. Hazır olunca otomatik oynatılacak.</p>
              </div>
            )}

            {vidStatus === 'error' && (
              <div style={s.vidOverlay}>
                <p style={s.errorIcon}>!</p>
                <p style={s.vidHint}>{vidError || 'Video hazırlanamadı.'}</p>
                <button style={s.retryBtn} onClick={startDownload}>Tekrar dene</button>
              </div>
            )}

            {vidStatus === 'ready' && mediaSrc && (
              <video ref={videoRef} src={mediaSrc} style={s.video}
                preload="auto" autoPlay
                onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)}
                onEnded={() => setPlaying(false)}
                onTimeUpdate={onTimeUpdate}
                onLoadedMetadata={e => setDuration(e.target.duration)}
                onError={() => setError('Video oynatılamadı.')}
                onClick={() => videoRef.current?.paused ? videoRef.current.play() : videoRef.current?.pause()}
              />
            )}

            {vidStatus === 'ready' && mediaSrc && (
              <div style={{...s.controls, opacity: showCtrl ? 1 : 0}}>
                <div style={s.seekTrack} onClick={seek}>
                  <div style={{...s.seekBuf, width:`${buffered * 100}%`}}/>
                  <div style={{...s.seekFill, width: duration ? `${(progress / duration) * 100}%` : '0%'}}/>
                  <div style={{...s.seekThumb, left: duration ? `${(progress / duration) * 100}%` : '0%'}}/>
                </div>
                <div style={s.ctrlRow}>
                  <div style={s.ctrlLeft}>
                    <button style={s.ctrlBtn}
                      onClick={() => videoRef.current?.paused ? videoRef.current.play() : videoRef.current?.pause()}>
                      {playing
                        ? <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
                        : <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>}
                    </button>
                    <span style={s.timeLabel}>{fmtTime(progress)} / {fmtTime(duration)}</span>
                    <input type="range" min="0" max="1" step="0.05" value={volume} style={s.volSlider}
                      onChange={e => { const v = parseFloat(e.target.value); setVolume(v); if (videoRef.current) videoRef.current.volume = v; }}/>
                  </div>
                  <button style={s.ctrlBtn} onClick={() => videoRef.current?.requestFullscreen()}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>
                    </svg>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {!loading && !error && item.media_type === 'AUDIO' && mediaSrc && (
          <div style={s.audioBox}>
            <div style={s.audioIcon}>♪</div>
            <p style={s.audioName}>{item.filename}</p>
            <audio ref={videoRef} controls src={mediaSrc} style={s.audioEl}
              onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)}/>
          </div>
        )}

        {!loading && !error && item.media_type === 'DOCUMENT' && (
          <div style={s.docBox}>
            <div style={s.docBigIcon}>{docLabel()}</div>
            <p style={s.docName}>{item.filename}</p>
            {fmtSize && <p style={s.docSize}>{fmtSize}</p>}
            <button style={s.docDlBtn} onClick={handleDownload} disabled={dlState === 'loading'}>
              {dlState === 'loading' ? 'İndiriliyor...' : 'Dosyayı indir'}
            </button>
          </div>
        )}

        {items && idx < items.length - 1 && (
          <button style={{...s.navBtn, right:16}} onClick={() => onNavigate('next')} title="Sonraki">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        )}
      </div>

      {items && items.length > 1 && (
        <div style={s.filmStrip} onClick={e => e.stopPropagation()}>
          {items.slice(Math.max(0, idx - 4), idx + 5).map(it => {
            const active = it.id === item.id && String(it.channel_id) === String(item.channel_id);
            return (
              <FilmThumb key={`${it.channel_id}-${it.id}`}
                url={`${BASE}/thumbnail/${it.channel_id || 'me'}/${it.id}?token=${token}`}
                active={active} isVideo={it.media_type === 'VIDEO'}
                onClick={() => onNavigate('goto', it)}/>
            );
          })}
        </div>
      )}
    </div>
  );
}

function FilmThumb({ url, active, isVideo, onClick }) {
  const [src, setSrc] = useState(null);
  useEffect(() => {
    let objectUrl;
    fetch(url)
      .then(r => r.ok ? r.blob() : null)
      .then(b => {
        if (!b) return;
        objectUrl = URL.createObjectURL(b);
        setSrc(objectUrl);
      })
      .catch(() => {});
    return () => { if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [url]);

  return (
    <div style={{...ft.wrap, outline: active ? '2px solid #d4a847' : 'none', opacity: active ? 1 : 0.45}}
      onClick={onClick}>
      {src ? <img src={src} alt="" style={ft.img} loading="lazy" decoding="async"/> : <div style={ft.empty}>{isVideo ? '▶' : '●'}</div>}
    </div>
  );
}

const ft = {
  wrap:  { width:52, height:52, borderRadius:6, overflow:'hidden', cursor:'pointer', background:'rgba(255,255,255,0.06)', flexShrink:0, transition:'opacity 0.15s, outline 0.15s' },
  img:   { width:'100%', height:'100%', objectFit:'cover' },
  empty: { width:'100%', height:'100%', display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, color:'rgba(255,255,255,0.3)' },
};

const s = {
  backdrop:     { position:'fixed', inset:0, background:'rgba(6,6,5,0.97)', zIndex:1000, display:'flex', flexDirection:'column', animation:'fadeIn 0.2s ease' },
  header:       { display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 20px', borderBottom:'1px solid rgba(255,255,255,0.06)', flexShrink:0 },
  hLeft:        { display:'flex', alignItems:'center', gap:14, minWidth:0 },
  hRight:       { display:'flex', alignItems:'center', gap:10, flexShrink:0 },
  titleBox:     { minWidth:0 },
  iconBtn:      { background:'none', border:'none', color:'rgba(255,255,255,0.5)', cursor:'pointer', padding:4, display:'flex', borderRadius:6 },
  fname:        { fontSize:13, color:'rgba(255,255,255,0.7)', margin:0, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', maxWidth:520 },
  fmeta:        { fontSize:11, color:'rgba(255,255,255,0.3)', margin:'2px 0 0' },
  counter:      { fontSize:12, color:'rgba(255,255,255,0.3)', fontVariantNumeric:'tabular-nums' },
  dlBtn:        { display:'flex', alignItems:'center', gap:6, background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.12)', color:'rgba(255,255,255,0.75)', borderRadius:8, padding:'6px 12px', cursor:'pointer', fontSize:12, fontFamily:'inherit', transition:'all 0.15s' },
  spinSm:       { width:11, height:11, border:'1.5px solid rgba(255,255,255,0.2)', borderTopColor:'rgba(255,255,255,0.7)', borderRadius:'50%', animation:'spin 0.7s linear infinite', flexShrink:0 },
  mediaArea:    { flex:1, display:'flex', alignItems:'center', justifyContent:'center', position:'relative', overflow:'hidden', padding:'16px 60px' },
  navBtn:       { position:'absolute', top:'50%', transform:'translateY(-50%)', background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.1)', color:'#fff', cursor:'pointer', width:44, height:44, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', zIndex:10 },
  spinWrap:     { display:'flex', alignItems:'center', justifyContent:'center' },
  spinner:      { width:36, height:36, border:'2px solid rgba(255,255,255,0.1)', borderTopColor:'#d4a847', borderRadius:'50%', animation:'spin 0.8s linear infinite' },
  errorBox:     { display:'flex', flexDirection:'column', alignItems:'center', gap:10, color:'rgba(255,255,255,0.55)' },
  errorIcon:    { width:38, height:38, borderRadius:'50%', border:'1px solid rgba(192,80,80,0.45)', color:'#e87070', display:'flex', alignItems:'center', justifyContent:'center', fontSize:24, margin:0 },
  photo:        { maxWidth:'100%', maxHeight:'100%', objectFit:'contain', borderRadius:4, userSelect:'none' },
  videoWrap:    { position:'relative', width:'100%', maxWidth:960, aspectRatio:'16/9', background:'#000', borderRadius:8 },
  vidOverlay:   { position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:12, padding:24, textAlign:'center' },
  vidPctText:   { fontSize:24, fontWeight:600, color:'#d4a847' },
  vidHint:      { fontSize:12, color:'rgba(255,255,255,0.48)', maxWidth:360, lineHeight:1.6 },
  retryBtn:     { background:'#d4a847', color:'#0a0a09', border:'none', borderRadius:8, padding:'9px 16px', cursor:'pointer', fontSize:12, fontWeight:600, fontFamily:'inherit' },
  progressTrack:{ width:240, height:4, background:'rgba(255,255,255,0.15)', borderRadius:99, overflow:'hidden' },
  progressFill: { height:'100%', background:'#d4a847', borderRadius:99, transition:'width 0.5s ease' },
  video:        { width:'100%', height:'100%', objectFit:'contain', borderRadius:8, cursor:'pointer' },
  controls:     { position:'absolute', bottom:0, left:0, right:0, padding:'28px 14px 12px', background:'linear-gradient(to top, rgba(0,0,0,0.88), transparent)', transition:'opacity 0.3s ease', borderRadius:'0 0 8px 8px' },
  seekTrack:    { position:'relative', height:4, background:'rgba(255,255,255,0.15)', borderRadius:99, cursor:'pointer', marginBottom:10 },
  seekBuf:      { position:'absolute', top:0, left:0, height:'100%', background:'rgba(255,255,255,0.2)', borderRadius:99, pointerEvents:'none' },
  seekFill:     { position:'absolute', top:0, left:0, height:'100%', background:'#d4a847', borderRadius:99, pointerEvents:'none' },
  seekThumb:    { position:'absolute', top:'50%', transform:'translate(-50%,-50%)', width:12, height:12, background:'#d4a847', borderRadius:'50%', pointerEvents:'none' },
  ctrlRow:      { display:'flex', alignItems:'center', justifyContent:'space-between' },
  ctrlLeft:     { display:'flex', alignItems:'center', gap:10 },
  ctrlBtn:      { background:'none', border:'none', color:'#fff', cursor:'pointer', display:'flex', alignItems:'center', padding:'4px 6px', opacity:0.85 },
  timeLabel:    { fontSize:12, color:'rgba(255,255,255,0.65)', fontVariantNumeric:'tabular-nums' },
  volSlider:    { width:68, accentColor:'#d4a847', cursor:'pointer' },
  audioBox:     { display:'flex', flexDirection:'column', alignItems:'center', gap:16 },
  audioIcon:    { fontSize:64, color:'#d4a847', opacity:0.7 },
  audioName:    { fontSize:14, color:'rgba(255,255,255,0.6)' },
  audioEl:      { width:320 },
  docBox:       { display:'flex', flexDirection:'column', alignItems:'center', gap:14 },
  docBigIcon:   { fontSize:28, color:'#d4a847', border:'1px solid rgba(212,168,71,0.35)', borderRadius:10, padding:'18px 22px', fontWeight:700 },
  docName:      { fontSize:15, color:'rgba(255,255,255,0.7)', textAlign:'center', maxWidth:400 },
  docSize:      { fontSize:12, color:'rgba(255,255,255,0.3)' },
  docDlBtn:     { display:'flex', alignItems:'center', gap:8, background:'#d4a847', color:'#0a0a09', border:'none', borderRadius:10, padding:'12px 24px', fontSize:14, fontWeight:500, cursor:'pointer', fontFamily:'inherit', marginTop:8 },
  filmStrip:    { display:'flex', gap:6, padding:'10px 20px', overflowX:'auto', flexShrink:0, borderTop:'1px solid rgba(255,255,255,0.06)', scrollbarWidth:'none' },
};
