import { useRef, useState } from 'react';

const ALLOWED_EXT = [
  'jpg','jpeg','png','gif','webp','heic',
  'mp4','mov','avi','mkv','webm',
  'mp3','wav','flac','aac','ogg',
  'pdf','doc','docx','xls','xlsx','ppt','pptx',
  'zip','rar','7z','tar','gz',
  'txt','md','json','csv',
];

export function Toolbar({ onUpload, uploading, uploadProgress, search, onSearch, viewMode, onViewMode, totalItems }) {
  const fileRef = useRef();
  const [dragOver, setDragOver] = useState(false);

  const handleFiles = files => {
    if (!files?.length) return;
    const valid = Array.from(files).filter(f => {
      const ext = f.name.split('.').pop().toLowerCase();
      return ALLOWED_EXT.includes(ext) || f.type.startsWith('image/') || f.type.startsWith('video/') || f.type.startsWith('audio/');
    });
    if (valid.length) onUpload(valid);
  };

  const onDrop = e => {
    e.preventDefault();
    setDragOver(false);
    handleFiles(e.dataTransfer.files);
  };

  return (
    <div style={s.wrap}
      onDragOver={e => { e.preventDefault(); setDragOver(true); }}
      onDragLeave={() => setDragOver(false)}
      onDrop={onDrop}
    >
      {dragOver && <div style={s.dropOverlay}><p style={s.dropText}>Bırak ve yükle</p></div>}

      <div style={s.searchBox}>
        <svg style={s.searchIcon} width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input style={s.searchInput} placeholder="Dosya ara..."
          value={search} onChange={e => onSearch(e.target.value)} />
        {search && (
          <button style={s.clearBtn} onClick={() => onSearch('')} title="Aramayı temizle">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        )}
      </div>

      <div style={s.right}>
        {totalItems > 0 && <span style={s.count}>{totalItems} öğe</span>}

        <div style={s.viewToggle}>
          {['grid','list'].map(mode => (
            <button key={mode} title={mode === 'grid' ? 'Izgara' : 'Liste'}
              style={{...s.viewBtn, background: viewMode === mode ? 'var(--bg-overlay)' : 'none'}}
              onClick={() => onViewMode(mode)}>
              {mode === 'grid'
                ? <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" opacity="0.75"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                : <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity="0.75"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="3" cy="6" r="1.2" fill="currentColor"/><circle cx="3" cy="12" r="1.2" fill="currentColor"/><circle cx="3" cy="18" r="1.2" fill="currentColor"/></svg>
              }
            </button>
          ))}
        </div>

        <input ref={fileRef} type="file" multiple style={{display:'none'}}
          onChange={e => { handleFiles(e.target.files); e.target.value = ''; }} />
        <button style={{...s.uploadBtn, ...(uploading ? s.uploadingBtn : {})}}
          onClick={() => !uploading && fileRef.current.click()} disabled={uploading}>
          {uploading ? (
            <><span style={s.spinEl} /><span style={s.uploadText}>{uploadProgress || 'Yükleniyor...'}</span></>
          ) : (
            <><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="5 12 12 5 19 12"/></svg>Yükle</>
          )}
        </button>
      </div>
    </div>
  );
}

const s = {
  wrap:        { display:'flex', alignItems:'center', gap:10, padding:'10px 20px', borderBottom:'1px solid var(--border)', background:'var(--bg-raised)', flexShrink:0, position:'relative' },
  dropOverlay: { position:'absolute', inset:0, background:'rgba(212,168,71,0.12)', border:'2px dashed var(--accent)', borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', zIndex:10 },
  dropText:    { fontSize:14, fontWeight:500, color:'var(--accent)' },
  searchBox:   { flex:1, display:'flex', alignItems:'center', gap:8, background:'var(--bg-overlay)', border:'1px solid var(--border)', borderRadius:8, padding:'7px 12px', transition:'border-color 0.15s', minWidth:160 },
  searchIcon:  { color:'var(--text-muted)', flexShrink:0 },
  searchInput: { flex:1, background:'none', border:'none', outline:'none', color:'var(--text-primary)', fontSize:13, fontFamily:'var(--font-body)', fontWeight:300, minWidth:0 },
  clearBtn:    { background:'none', border:'none', color:'var(--text-muted)', cursor:'pointer', display:'flex', padding:2, borderRadius:4 },
  right:       { display:'flex', alignItems:'center', gap:8, flexShrink:0 },
  count:       { fontSize:11, color:'var(--text-muted)', fontVariantNumeric:'tabular-nums', minWidth:50 },
  viewToggle:  { display:'flex', gap:1, background:'var(--bg-overlay)', padding:3, borderRadius:7, border:'1px solid var(--border)' },
  viewBtn:     { background:'none', border:'none', color:'var(--text-secondary)', cursor:'pointer', padding:'4px 7px', borderRadius:5, display:'flex', alignItems:'center', transition:'background 0.15s' },
  uploadBtn:   { display:'flex', alignItems:'center', justifyContent:'center', gap:6, background:'var(--accent)', color:'#0a0a09', border:'none', borderRadius:8, padding:'8px 14px', fontSize:12, fontWeight:500, cursor:'pointer', fontFamily:'var(--font-body)', flexShrink:0, transition:'all 0.15s', minWidth:76 },
  uploadingBtn:{ background:'var(--bg-overlay)', color:'var(--text-secondary)', cursor:'not-allowed', border:'1px solid var(--border)' },
  uploadText:  { maxWidth:120, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' },
  spinEl:      { width:11, height:11, border:'1.5px solid rgba(255,255,255,0.2)', borderTopColor:'var(--text-secondary)', borderRadius:'50%', animation:'spin 0.7s linear infinite', flexShrink:0 },
};
