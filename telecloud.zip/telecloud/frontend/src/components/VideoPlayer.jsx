/**
 * components/VideoPlayer.jsx
 * HTTP Range destekli HTML5 video oynatıcı.
 * Özel kontrol çubuğu: oynat/durdur, seek, ses, tam ekran, sure.
 */

import { useCallback, useEffect, useRef, useState } from 'react';

// ── Yardımcılar ───────────────────────────────────────────────────────────────

function fmtTime(sec) {
  if (!sec || isNaN(sec)) return '0:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

// ── Bileşen ───────────────────────────────────────────────────────────────────

/**
 * @param {{ src: string, poster?: string, autoPlay?: boolean }} props
 */
export function VideoPlayer({ src, poster, autoPlay = false }) {
  const videoRef    = useRef(null);
  const barRef      = useRef(null);
  const hideTimer   = useRef(null);

  const [playing,   setPlaying]   = useState(false);
  const [progress,  setProgress]  = useState(0);    // 0-1
  const [buffered,  setBuffered]  = useState(0);    // 0-1
  const [volume,    setVolume]    = useState(1);
  const [muted,     setMuted]     = useState(false);
  const [duration,  setDuration]  = useState(0);
  const [current,   setCurrent]   = useState(0);
  const [showCtrl,  setShowCtrl]  = useState(true);
  const [fullscreen,setFullscreen]= useState(false);

  // ── Video olayları ────────────────────────────────────────────────────────
  const onTimeUpdate = () => {
    const v = videoRef.current;
    if (!v) return;
    setCurrent(v.currentTime);
    setProgress(v.duration ? v.currentTime / v.duration : 0);

    // Buffer doluluk oranı
    if (v.buffered.length > 0) {
      setBuffered(v.buffered.end(v.buffered.length - 1) / v.duration);
    }
  };

  const onLoadedMetadata = () => {
    if (videoRef.current) setDuration(videoRef.current.duration);
  };

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    v.addEventListener('timeupdate', onTimeUpdate);
    v.addEventListener('loadedmetadata', onLoadedMetadata);
    v.addEventListener('play',  () => setPlaying(true));
    v.addEventListener('pause', () => setPlaying(false));
    v.addEventListener('ended', () => setPlaying(false));
    return () => {
      v.removeEventListener('timeupdate', onTimeUpdate);
      v.removeEventListener('loadedmetadata', onLoadedMetadata);
    };
  }, []);

  // ── Kontrol göster/gizle ──────────────────────────────────────────────────
  const revealControls = () => {
    setShowCtrl(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => {
      if (playing) setShowCtrl(false);
    }, 3000);
  };

  useEffect(() => () => clearTimeout(hideTimer.current), []);

  // ── Oynat / Durdur ────────────────────────────────────────────────────────
  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    playing ? v.pause() : v.play();
  }, [playing]);

  // Boşluk tuşu desteği
  useEffect(() => {
    const onKey = e => {
      if (e.code === 'Space' && e.target === document.body) {
        e.preventDefault();
        togglePlay();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePlay]);

  // ── Seek (ileri / geri atlama) ────────────────────────────────────────────
  const onSeek = e => {
    const bar  = barRef.current;
    const v    = videoRef.current;
    if (!bar || !v) return;
    const rect = bar.getBoundingClientRect();
    const pct  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    v.currentTime = pct * v.duration;
  };

  // ── Ses ───────────────────────────────────────────────────────────────────
  const onVolumeChange = e => {
    const val = parseFloat(e.target.value);
    if (videoRef.current) videoRef.current.volume = val;
    setVolume(val);
    setMuted(val === 0);
  };

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !muted;
    setMuted(!muted);
  };

  // ── Tam Ekran ─────────────────────────────────────────────────────────────
  const toggleFullscreen = () => {
    const el = videoRef.current?.closest('.vp-wrap');
    if (!document.fullscreenElement) {
      el?.requestFullscreen();
      setFullscreen(true);
    } else {
      document.exitFullscreen();
      setFullscreen(false);
    }
  };

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div
      className="vp-wrap"
      onMouseMove={revealControls}
      onMouseLeave={() => playing && setShowCtrl(false)}
      style={styles.wrap}
    >
      <video
        ref={videoRef}
        src={src}
        poster={poster}
        autoPlay={autoPlay}
        playsInline
        preload="metadata"
        onClick={togglePlay}
        style={styles.video}
      />

      {/* Oynat/Durdur merkez animasyonu */}
      {!playing && (
        <div style={styles.playOverlay} onClick={togglePlay}>
          <PlayIcon size={56} />
        </div>
      )}

      {/* Kontrol çubuğu */}
      <div style={{ ...styles.controls, opacity: showCtrl ? 1 : 0 }}>

        {/* Seek bar */}
        <div ref={barRef} style={styles.seekBar} onClick={onSeek}>
          <div style={{ ...styles.seekFill, width: `${buffered * 100}%`, background: 'rgba(255,255,255,0.2)' }} />
          <div style={{ ...styles.seekFill, width: `${progress * 100}%`, background: 'var(--accent)' }} />
          <div style={{ ...styles.seekThumb, left: `${progress * 100}%` }} />
        </div>

        <div style={styles.row}>
          {/* Sol: oynat, ses, süre */}
          <div style={styles.left}>
            <button style={styles.btn} onClick={togglePlay} aria-label="Oynat/Durdur">
              {playing ? <PauseIcon /> : <PlayIcon />}
            </button>
            <button style={styles.btn} onClick={toggleMute} aria-label="Sessiz">
              {muted || volume === 0 ? <MuteIcon /> : <VolumeIcon />}
            </button>
            <input
              type="range" min="0" max="1" step="0.02"
              value={muted ? 0 : volume}
              onChange={onVolumeChange}
              style={styles.volSlider}
              aria-label="Ses"
            />
            <span style={styles.time}>{fmtTime(current)} / {fmtTime(duration)}</span>
          </div>

          {/* Sağ: tam ekran */}
          <div>
            <button style={styles.btn} onClick={toggleFullscreen} aria-label="Tam ekran">
              {fullscreen ? <ExitFsIcon /> : <FullscreenIcon />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Stiller ───────────────────────────────────────────────────────────────────

const styles = {
  wrap: {
    position: 'relative',
    background: '#000',
    borderRadius: 'var(--radius-lg)',
    overflow: 'hidden',
    aspectRatio: '16/9',
    cursor: 'pointer',
    userSelect: 'none',
  },
  video: {
    width: '100%',
    height: '100%',
    objectFit: 'contain',
    display: 'block',
  },
  playOverlay: {
    position: 'absolute',
    inset: 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'rgba(0,0,0,0.35)',
  },
  controls: {
    position: 'absolute',
    bottom: 0, left: 0, right: 0,
    padding: '32px 16px 12px',
    background: 'linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 100%)',
    transition: 'opacity 0.3s ease',
  },
  seekBar: {
    position: 'relative',
    height: 3,
    background: 'rgba(255,255,255,0.15)',
    borderRadius: 99,
    marginBottom: 10,
    cursor: 'pointer',
  },
  seekFill: {
    position: 'absolute',
    top: 0, left: 0,
    height: '100%',
    borderRadius: 99,
    pointerEvents: 'none',
  },
  seekThumb: {
    position: 'absolute',
    top: '50%',
    transform: 'translate(-50%,-50%)',
    width: 12, height: 12,
    background: 'var(--accent)',
    borderRadius: '50%',
    pointerEvents: 'none',
    transition: 'transform 0.1s',
  },
  row: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  left: { display: 'flex', alignItems: 'center', gap: 8 },
  btn: {
    background: 'none',
    border: 'none',
    color: '#fff',
    cursor: 'pointer',
    padding: '4px 6px',
    display: 'flex',
    alignItems: 'center',
    opacity: 0.85,
  },
  volSlider: {
    width: 72,
    accentColor: 'var(--accent)',
    cursor: 'pointer',
  },
  time: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.7)',
    fontFamily: 'var(--font-ui)',
    fontVariantNumeric: 'tabular-nums',
  },
};

// ── SVG İkonlar ───────────────────────────────────────────────────────────────

const SvgWrap = ({ size = 20, children }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    {children}
  </svg>
);

const PlayIcon     = ({ size }) => <SvgWrap size={size}><polygon points="5 3 19 12 5 21 5 3"/></SvgWrap>;
const PauseIcon    = ()          => <SvgWrap><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></SvgWrap>;
const VolumeIcon   = ()          => <SvgWrap><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/></SvgWrap>;
const MuteIcon     = ()          => <SvgWrap><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></SvgWrap>;
const FullscreenIcon = ()        => <SvgWrap><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></SvgWrap>;
const ExitFsIcon   = ()          => <SvgWrap><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"/></SvgWrap>;
