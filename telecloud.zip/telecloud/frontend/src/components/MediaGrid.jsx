import { useCallback, useEffect, useRef, useState } from 'react';
import { useAuth } from '../hooks/useAuth.jsx';
import { Sidebar } from './Sidebar.jsx';
import { Toolbar } from './Toolbar.jsx';
import { MediaCard } from './MediaCard.jsx';
import { Viewer } from './Viewer.jsx';
import { BASE_URL, authHeaders } from '../api/client.js';

const BASE = BASE_URL;
const PAGE = 40;

export function MediaGrid() {
  const { user, logout, accessToken } = useAuth();

  const [channels, setChannels] = useState([]);
  const [activeChannel, setActiveChannel] = useState('me');
  const [storage, setStorage] = useState(null);
  const [items, setItems] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);

  const [filter, setFilter] = useState(undefined);
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState('grid');
  const [selected, setSelected] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadMsg, setUploadMsg] = useState('');

  const sentinelRef = useRef();
  const searchTimer = useRef();
  const loadRun = useRef(0);
  const loadingRef = useRef(false);

  useEffect(() => {
    if (!accessToken) return;
    fetch(`${BASE}/channels`, { headers: authHeaders(accessToken) })
      .then(r => r.json())
      .then(d => setChannels(d.channels || []))
      .catch(() => {});

    fetch(`${BASE}/storage/info`, { headers: authHeaders(accessToken) })
      .then(r => r.json())
      .then(setStorage)
      .catch(() => {});
  }, [accessToken]);

  const loadMedia = useCallback(async (pg, reset) => {
    if (!accessToken) return;
    if (loadingRef.current && !reset) return;

    const runId = ++loadRun.current;
    loadingRef.current = true;
    setLoading(true);

    try {
      const qs = new URLSearchParams({ page: pg, page_size: PAGE });
      if (filter) qs.set('media_type', filter);
      if (search) qs.set('search', search);

      const res = await fetch(`${BASE}/media/channel/${activeChannel}?${qs}`, {
        headers: authHeaders(accessToken)
      });
      if (!res.ok) throw new Error('Medya yüklenemedi');

      const data = await res.json();
      if (runId !== loadRun.current) return;

      const got = data.items || [];
      setItems(prev => reset ? got : [...prev, ...got]);
      setHasMore(got.length >= PAGE);
    } catch(e) {
      console.error(e);
      if (runId === loadRun.current && reset) setItems([]);
    } finally {
      if (runId === loadRun.current) {
        loadingRef.current = false;
        setLoading(false);
      }
    }
  }, [accessToken, activeChannel, filter, search]);

  useEffect(() => {
    setItems([]);
    setPage(1);
    setHasMore(true);
    loadMedia(1, true);
  }, [activeChannel, filter]);

  useEffect(() => {
    clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => {
      setItems([]);
      setPage(1);
      setHasMore(true);
      loadMedia(1, true);
    }, 350);
    return () => clearTimeout(searchTimer.current);
  }, [search]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore && !loading) {
        const next = page + 1;
        setPage(next);
        loadMedia(next, false);
      }
    }, { rootMargin: '500px' });
    obs.observe(el);
    return () => obs.disconnect();
  }, [hasMore, loading, page, loadMedia]);

  const handleUpload = async (files) => {
    setUploading(true);
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setUploadMsg(`${i + 1}/${files.length}: ${file.name}`);
      const form = new FormData();
      form.append('file', file);
      form.append('channel_id', activeChannel);
      await fetch(`${BASE}/upload`, {
        method: 'POST',
        headers: authHeaders(accessToken),
        body: form,
      }).catch(() => {});
    }
    setUploading(false);
    setUploadMsg('');
    setItems([]);
    setPage(1);
    loadMedia(1, true);
  };

  const handleNewChannel = async (name) => {
    const res = await fetch(`${BASE}/channels/create`, {
      method: 'POST',
      headers: { ...authHeaders(accessToken), 'Content-Type': 'application/json' },
      body: JSON.stringify({ name })
    });
    const data = await res.json();
    setChannels(prev => [...prev, { id: data.id, name: data.name }]);
    setActiveChannel(String(data.id));
  };

  const navigate = (dir, target) => {
    const idx = items.findIndex(i => i.id === selected.id && i.channel_id === selected.channel_id);
    if (dir === 'next' && idx < items.length - 1) setSelected(items[idx + 1]);
    if (dir === 'prev' && idx > 0) setSelected(items[idx - 1]);
    if (dir === 'goto' && target) setSelected(target);
  };

  const cols = viewMode === 'grid' ? 'repeat(auto-fill, minmax(150px, 1fr))' : '1fr';
  const activeChannelName = channels.find(c => String(c.id) === activeChannel)?.name || 'Kayıtlı Mesajlar';

  return (
    <div style={s.shell}>
      <Sidebar
        channels={channels} activeChannel={activeChannel}
        onChannelSelect={setActiveChannel} onNewChannel={handleNewChannel}
        filter={filter} onFilterChange={setFilter}
        storage={storage} user={user}
      />

      <div style={s.main}>
        <div style={s.topBar}>
          <div style={s.breadcrumb}>
            <span style={s.breadChan}>{activeChannelName}</span>
            {filter && <><span style={s.breadSep}>›</span><span style={s.breadFilter}>{filter}</span></>}
          </div>
          <button onClick={logout} style={s.logoutBtn}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
              <polyline points="16 17 21 12 16 7"/>
              <line x1="21" y1="12" x2="9" y2="12"/>
            </svg>
            Çıkış
          </button>
        </div>

        <Toolbar
          onUpload={handleUpload} uploading={uploading} uploadProgress={uploadMsg}
          search={search} onSearch={setSearch}
          viewMode={viewMode} onViewMode={setViewMode}
          totalItems={items.length}
        />

        <div style={s.scrollArea}>
          {!loading && items.length === 0 && (
            <div style={s.empty}>
              <div style={s.emptyIcon}>☁</div>
              <p style={s.emptyTitle}>Bu depoda medya yok</p>
              <p style={s.emptyHint}>
                Yükle butonuna tıkla veya Telegram'dan<br/>
                Kayıtlı Mesajlar'a dosya gönder
              </p>
            </div>
          )}

          <div style={{...s.grid, gridTemplateColumns: cols}}>
            {items.map((item, idx) => (
              viewMode === 'grid'
                ? <MediaCard key={`${item.channel_id}-${item.id}`} item={item} token={accessToken}
                    onClick={setSelected} style={{ animationDelay: `${Math.min(idx, PAGE) * 12}ms` }} />
                : <ListRow key={`${item.channel_id}-${item.id}`} item={item} token={accessToken}
                    onClick={setSelected} />
            ))}
          </div>

          {loading && (
            <div style={s.loadRow}>
              {Array.from({length: 8}).map((_, i) => (
                <div key={i} style={s.skelCard} className="shimmer" />
              ))}
            </div>
          )}

          {hasMore && <div ref={sentinelRef} style={{ height: 1 }} />}
          {!hasMore && items.length > 0 && (
            <p style={s.endMsg}>{items.length} dosya · {activeChannelName}</p>
          )}

          <div style={{ height: 40 }} />
        </div>
      </div>

      {selected && (
        <Viewer item={selected} token={accessToken} items={items}
          onClose={() => setSelected(null)} onNavigate={navigate} />
      )}
    </div>
  );
}

function ListRow({ item, token, onClick }) {
  const [src, setSrc] = useState(null);
  useEffect(() => {
    let cancelled = false;
    fetch(`${BASE}/thumbnail/${item.channel_id || 'me'}/${item.id}?token=${token}`)
      .then(r => r.ok ? r.blob() : null)
      .then(b => {
        if (!b || cancelled) return;
        setSrc(URL.createObjectURL(b));
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [item.channel_id, item.id, token]);

  const icon = {'PHOTO':'●','VIDEO':'▶','AUDIO':'♪','DOCUMENT':'≡'}[item.media_type] || '≡';
  const fmtSize = item.file_size > 0 ? `${(item.file_size / 1e6).toFixed(1)} MB` : '-';
  const fmtDate = item.date ? new Date(item.date).toLocaleDateString('tr-TR', {day:'numeric',month:'short',year:'numeric'}) : '-';

  return (
    <div style={ls.row} onClick={() => onClick(item)}>
      <div style={ls.thumb}>
        {src ? <img src={src} alt="" style={ls.img} loading="lazy" decoding="async" /> : <span style={{fontSize:14, color:'var(--text-muted)'}}>{icon}</span>}
      </div>
      <div style={ls.info}>
        <span style={ls.name}>{item.filename}</span>
        <span style={ls.type}>{item.media_type}</span>
      </div>
      <span style={ls.date}>{fmtDate}</span>
      <span style={ls.size}>{fmtSize}</span>
    </div>
  );
}

const ls = {
  row:   { display:'flex', alignItems:'center', gap:12, padding:'8px 20px', cursor:'pointer', borderRadius:'var(--r-sm)', transition:'background 0.1s' },
  thumb: { width:40, height:40, borderRadius:6, overflow:'hidden', background:'var(--bg-overlay)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 },
  img:   { width:'100%', height:'100%', objectFit:'cover' },
  info:  { flex:1, display:'flex', flexDirection:'column', gap:2, overflow:'hidden' },
  name:  { fontSize:13, color:'var(--text-primary)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' },
  type:  { fontSize:10, color:'var(--text-muted)', letterSpacing:'0.06em' },
  date:  { fontSize:12, color:'var(--text-muted)', flexShrink:0, minWidth:80, textAlign:'right' },
  size:  { fontSize:12, color:'var(--text-muted)', flexShrink:0, minWidth:60, textAlign:'right' },
};

const s = {
  shell:    { display:'flex', height:'100vh', width:'100vw', overflow:'hidden', background:'var(--bg)' },
  main:     { flex:1, display:'flex', flexDirection:'column', overflow:'hidden', minWidth:0 },
  topBar:   { display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 20px', borderBottom:'1px solid var(--border)', flexShrink:0 },
  breadcrumb: { display:'flex', alignItems:'center', gap:8 },
  breadChan: { fontSize:14, fontWeight:500, color:'var(--text-primary)', fontFamily:'var(--font-display)' },
  breadSep:  { color:'var(--text-muted)', fontSize:12 },
  breadFilter: { fontSize:12, color:'var(--accent)', background:'var(--accent-dim)', padding:'2px 8px', borderRadius:99 },
  logoutBtn: { display:'flex', alignItems:'center', gap:6, background:'none', border:'none', color:'var(--text-muted)', cursor:'pointer', fontSize:12, padding:'6px 10px', borderRadius:'var(--r-sm)', transition:'color 0.15s', fontFamily:'var(--font-body)' },
  scrollArea:{ flex:1, overflowY:'auto', padding:'16px 20px 0' },
  grid:     { display:'grid', gap:8 },
  loadRow:  { display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(150px,1fr))', gap:8, marginTop:8 },
  skelCard: { borderRadius:'var(--r-md)', aspectRatio:'1/1' },
  empty:    { display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', minHeight:'60vh', gap:12, textAlign:'center' },
  emptyIcon:  { fontSize:64, opacity:0.15 },
  emptyTitle: { fontSize:16, color:'var(--text-secondary)', fontFamily:'var(--font-display)', fontWeight:500 },
  emptyHint:  { fontSize:13, color:'var(--text-muted)', lineHeight:1.7 },
  endMsg:   { textAlign:'center', padding:'32px 0', fontSize:11, color:'var(--text-dim)', letterSpacing:'0.08em', textTransform:'uppercase' },
};
