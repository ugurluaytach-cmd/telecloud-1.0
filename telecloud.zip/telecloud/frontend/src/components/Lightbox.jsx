/**
 * components/Lightbox.jsx
 * Tam ekran medya görüntüleyici.
 * Fotoğraflar için pinch-to-zoom benzeri fare büyütme, videolar için VideoPlayer.
 * Klavye: ← → gezinme, Esc kapat.
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { MediaType, streamUrl, thumbnailUrl } from '../api/mediaApi';
import { VideoPlayer } from './VideoPlayer';

/**
 * @param {{
 *   items: import('../api/mediaApi').MediaItem[],
 *   startIndex: number,
 *   onClose: () => void
 * }} props
 */
export function Lightbox({ items, startIndex, onClose }) {
  const [index,   setIndex]   = useState(startIndex);
  const [visible, setVisible] = useState(false);     // fade-in için
  const [imgLoaded, setImgLoaded] = useState(false);

  const item = items[index];

  // ── Açılış animasyonu ─────────────────────────────────────────────────────
  useEffect(() => {
    requestAnimationFrame(() => setVisible(true));
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  // ── Kapanış ───────────────────────────────────────────────────────────────
  const close = useCallback(() => {
    setVisible(false);
    setTimeout(onClose, 280);
  }, [onClose]);

  // ── Klavye navigasyonu ────────────────────────────────────────────────────
  useEffect(() => {
    const onKey = e => {
      if (e.key === 'Escape')     close();
      if (e.key === 'ArrowRight') next();
      if (e.key === 'ArrowLeft')  prev();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [index, close]);

  const prev = () => {
    setImgLoaded(false);
    setIndex(i => (i - 1 + items.length) % items.length);
  };
  const next = () => {
    setImgLoaded(false);
    setIndex(i => (i + 1) % items.length);
  };

  // ── Kaydırma ile gezinme ──────────────────────────────────────────────────
  const touchStart = useRef(null);
  const onTouchStart = e => { touchStart.current = e.touches[0].clientX; };
  const onTouchEnd   = e => {
    if (!touchStart.current) return;
    const dx = e.changedTouches[0].clientX - touchStart.current;
    if (Math.abs(dx) > 50) dx < 0 ? next() : prev();
    touchStart.current = null;
  };

  if (!item) return null;
  const isVideo = item.media_type === MediaType.VIDEO;

  return (
    <div
      style={{ ...s.backdrop, opacity: visible ? 1 : 0 }}
      onClick={e => e.target === e.currentTarget && close()}
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
    >
      {/* Üst çubuk */}
      <header style={s.header}>
        <span style={s.filename}>{item.filename}</span>
        <div style={s.headerRight}>
          <span style={s.counter}>{index + 1} / {items.length}</span>
          <button style={s.closeBtn} onClick={close} aria-label="Kapat">
            <CloseIcon />
          </button>
        </div>
      </header>

      {/* Sol ok */}
      {items.length > 1 && (
        <button style={{ ...s.navBtn, left: 16 }} onClick={prev} aria-label="Önceki">
          <ChevronIcon dir="left" />
        </button>
      )}

      {/* Medya alanı */}
      <div style={s.mediaWrap}>
        {isVideo ? (
          <div style={s.videoBox}>
            <VideoPlayer
              src={streamUrl(item.id)}
              poster={thumbnailUrl(item.id, 'md')}
              autoPlay
            />
          </div>
        ) : (
          <>
            {!imgLoaded && <Skeleton />}
            <img
              key={item.id}
              src={thumbnailUrl(item.id, 'md')}  // önce md thumbnail
              data-full={streamUrl(item.id)}       // tam çözünürlük (stream)
              alt={item.filename}
              style={{
                ...s.photo,
                opacity: imgLoaded ? 1 : 0,
                transition: 'opacity 0.3s ease',
              }}
              onLoad={e => {
                setImgLoaded(true);
                // Tam çözünürlüğü arka planda yükle, hazır olunca src değiştir
                const full = new Image();
                full.src = e.target.dataset.full;
                full.onload = () => { e.target.src = full.src; };
              }}
            />
          </>
        )}
      </div>

      {/* Sağ ok */}
      {items.length > 1 && (
        <button style={{ ...s.navBtn, right: 16 }} onClick={next} aria-label="Sonraki">
          <ChevronIcon dir="right" />
        </button>
      )}

      {/* Alt bilgi şeridi */}
      <footer style={s.footer}>
        <MetaRow item={item} />
        {/* Thumbnail film şeridi */}
        <FilmStrip items={items} activeIndex={index} onSelect={i => { setImgLoaded(false); setIndex(i); }} />
      </footer>
    </div>
  );
}

// ── Alt bileşenler ────────────────────────────────────────────────────────────

function MetaRow({ item }) {
  const size = item.file_size_bytes
    ? item.file_size_bytes > 1_000_000
      ? `${(item.file_size_bytes / 1_000_000).toFixed(1)} MB`
      : `${Math.round(item.file_size_bytes / 1024)} KB`
    : null;
  const date = item.uploaded_at
    ? new Date(item.uploaded_at).toLocaleDateString('tr-TR', { year: 'numeric', month: 'long', day: 'numeric' })
    : null;
  return (
    <div style={s.meta}>
      {date && <span>{date}</span>}
      {item.width && item.height && <span>{item.width} × {item.height}</span>}
      {item.duration_sec && <span>{Math.floor(item.duration_sec / 60)}:{String(item.duration_sec % 60).padStart(2, '0')}</span>}
      {size && <span>{size}</span>}
    </div>
  );
}

function FilmStrip({ items, activeIndex, onSelect }) {
  const stripRef = useRef(null);
  useEffect(() => {
    const el = stripRef.current?.children[activeIndex];
    el?.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
  }, [activeIndex]);

  return (
    <div ref={stripRef} style={s.strip}>
      {items.map((item, i) => (
        <button
          key={item.id}
          onClick={() => onSelect(i)}
          style={{
            ...s.stripThumb,
            outline: i === activeIndex ? '2px solid var(--accent)' : '2px solid transparent',
            opacity: i === activeIndex ? 1 : 0.5,
          }}
        >
          <img
            src={thumbnailUrl(item.id, 'xs')}
            alt=""
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
          {item.media_type === MediaType.VIDEO && (
            <span style={s.stripPlay}>▶</span>
          )}
        </button>
      ))}
    </div>
  );
}

function Skeleton() {
  return (
    <div style={{
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(90deg, var(--bg-raised) 25%, var(--bg-overlay) 50%, var(--bg-raised) 75%)',
      backgroundSize: '200% 100%',
      animation: 'shimmer 1.4s infinite',
      borderRadius: 'var(--radius-md)',
    }} />
  );
}

// ── Stiller ───────────────────────────────────────────────────────────────────

const s = {
  backdrop: {
    position: 'fixed', inset: 0, zIndex: 1000,
    background: 'rgba(8,8,7,0.96)',
    backdropFilter: 'blur(12px)',
    display: 'flex', flexDirection: 'column',
    transition: 'opacity 0.28s ease',
  },
  header: {
    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    padding: '14px 20px',
    borderBottom: '1px solid var(--border)',
    flexShrink: 0,
  },
  filename: { fontSize: 13, color: 'var(--text-secondary)', fontFamily: 'var(--font-ui)' },
  headerRight: { display: 'flex', alignItems: 'center', gap: 16 },
  counter: { fontSize: 12, color: 'var(--text-muted)', fontVariantNumeric: 'tabular-nums' },
  closeBtn: {
    background: 'none', border: 'none',
    color: 'var(--text-secondary)', cursor: 'pointer',
    padding: 6, borderRadius: 'var(--radius-sm)',
    display: 'flex', alignItems: 'center',
    transition: 'color 0.15s',
  },
  navBtn: {
    position: 'absolute', top: '50%', transform: 'translateY(-50%)',
    background: 'rgba(255,255,255,0.08)',
    border: '1px solid var(--border-mid)',
    color: 'var(--text-primary)',
    cursor: 'pointer', zIndex: 10,
    width: 44, height: 44, borderRadius: '50%',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    transition: 'background 0.15s',
  },
  mediaWrap: {
    flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
    position: 'relative', overflow: 'hidden', padding: '16px 72px',
  },
  videoBox: { width: '100%', maxWidth: 900 },
  photo: {
    maxWidth: '100%', maxHeight: '100%',
    objectFit: 'contain',
    borderRadius: 'var(--radius-sm)',
    userSelect: 'none', pointerEvents: 'none',
  },
  footer: {
    padding: '12px 20px 16px',
    borderTop: '1px solid var(--border)',
    flexShrink: 0,
  },
  meta: {
    display: 'flex', gap: 20,
    fontSize: 11, color: 'var(--text-muted)',
    fontFamily: 'var(--font-ui)', letterSpacing: '0.03em',
    textTransform: 'uppercase', marginBottom: 10,
  },
  strip: {
    display: 'flex', gap: 6, overflowX: 'auto',
    scrollbarWidth: 'none', paddingBottom: 2,
  },
  stripThumb: {
    position: 'relative', flexShrink: 0,
    width: 52, height: 52,
    borderRadius: 'var(--radius-sm)',
    overflow: 'hidden', cursor: 'pointer',
    background: 'var(--bg-overlay)',
    border: 'none', padding: 0,
    transition: 'outline 0.15s, opacity 0.15s',
  },
  stripPlay: {
    position: 'absolute', inset: 0,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: 10, color: '#fff',
    background: 'rgba(0,0,0,0.4)',
  },
};

// ── İkonlar ───────────────────────────────────────────────────────────────────

const CloseIcon = () => (
  <svg width={18} height={18} viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
    <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
  </svg>
);

const ChevronIcon = ({ dir }) => (
  <svg width={18} height={18} viewBox="0 0 24 24" fill="none"
    stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    {dir === 'left'
      ? <polyline points="15 18 9 12 15 6"/>
      : <polyline points="9 18 15 12 9 6"/>}
  </svg>
);
