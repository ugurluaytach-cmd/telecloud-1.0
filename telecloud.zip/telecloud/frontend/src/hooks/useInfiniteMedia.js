import { useCallback, useEffect, useRef, useState } from 'react';
import { fetchMedia } from '../api/mediaApi';

export function useInfiniteMedia({ mediaType, pageSize=50, token } = {}) {
  const [items,   setItems]   = useState([]);
  const [page,    setPage]    = useState(1);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState(null);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => { setItems([]); setPage(1); setHasMore(true); setError(null); }, [mediaType]);

  useEffect(() => {
    if (!hasMore || !token) return;
    let cancelled = false;
    setLoading(true);
    fetchMedia({ page, pageSize, mediaType, token })
      .then(data => {
        if (cancelled) return;
        setItems(prev => page === 1 ? data.items : [...prev, ...data.items]);
        if (data.items.length < pageSize) setHasMore(false);
      })
      .catch(err => { if (!cancelled) { setError(err.message); setHasMore(false); } })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [page, mediaType, token, hasMore]);

  const observerRef = useRef(null);
  const sentinelRef = useCallback(node => {
    if (loading) return;
    observerRef.current?.disconnect();
    if (!node || !hasMore) return;
    observerRef.current = new IntersectionObserver(
      entries => { if (entries[0].isIntersecting) setPage(p => p + 1); },
      { rootMargin: '300px' }
    );
    observerRef.current.observe(node);
  }, [loading, hasMore]);

  return { items, loading, error, hasMore, sentinelRef };
}
