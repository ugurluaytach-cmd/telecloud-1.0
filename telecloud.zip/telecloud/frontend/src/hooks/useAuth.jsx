import { createContext, useCallback, useContext, useState } from 'react';
import { requestJson } from '../api/client.js';

const Ctx  = createContext(null);

export function AuthProvider({ children }) {
  const [user,        setUser]        = useState(null);
  const [accessToken, setAccessToken] = useState(null);

  const loginWithTelegram = useCallback(async (phone, code) => {
    const data = await requestJson('/auth/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, code })
    });
    setAccessToken(data.token);
    setUser(data.user);
  }, []);

  const logout = useCallback(() => { setUser(null); setAccessToken(null); }, []);

  return (
    <Ctx.Provider value={{ user, accessToken, loading: false, loginWithTelegram, logout }}>
      {children}
    </Ctx.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useAuth AuthProvider içinde olmalı');
  return ctx;
}
