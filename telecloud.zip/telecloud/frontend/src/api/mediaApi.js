import { BASE_URL } from './client.js';

export const MediaType = { PHOTO:'PHOTO', VIDEO:'VIDEO', AUDIO:'AUDIO', DOCUMENT:'DOCUMENT' };

export async function fetchMedia({ page=1, pageSize=50, mediaType, token } = {}) {
  const qs = new URLSearchParams({ page, page_size: pageSize });
  if (mediaType) qs.set('media_type', mediaType);
  const res = await fetch(`${BASE_URL}/media?${qs}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (res.status === 401) throw new Error('Giris gerekli');
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export function thumbnailUrl(id, variant='sm') {
  return `${BASE_URL}/thumbnail/${id}/${variant}`;
}
export function streamUrl(id) {
  return `${BASE_URL}/stream/${id}`;
}
export async function deleteMedia(id, token) {
  return fetch(`${BASE_URL}/media/${id}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });
}
export { BASE_URL };
