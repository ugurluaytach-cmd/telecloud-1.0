import { BASE_URL } from './client.js';

export function videoStatusUrl(channelId, messageId, token) {
  return `${BASE_URL}/video/status/${channelId || 'me'}/${messageId}?token=${token}`;
}

export function videoCacheUrl(channelId, messageId, token) {
  return `${BASE_URL}/video/cache/${channelId || 'me'}/${messageId}?token=${token}`;
}

export function videoPlayUrl(channelId, messageId, token) {
  return `${BASE_URL}/video/play/${channelId || 'me'}/${messageId}?token=${token}`;
}

export async function getVideoStatus(channelId, messageId, token) {
  const res = await fetch(videoStatusUrl(channelId, messageId, token));
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export async function startVideoCache(channelId, messageId, token) {
  const res = await fetch(videoCacheUrl(channelId, messageId, token), { method: 'POST' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}
