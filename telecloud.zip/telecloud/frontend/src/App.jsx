import './styles/globals.css';
import { AuthProvider, useAuth } from './hooks/useAuth.jsx';
import { MediaGrid }  from './components/MediaGrid.jsx';
import { LoginPage }  from './components/LoginPage.jsx';

function Inner() {
  const { user, loading } = useAuth();
  if (loading) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'100vh',background:'var(--bg)'}}>
      <div style={{textAlign:'center'}}>
        <p style={{fontFamily:'var(--font-display)',fontSize:32,color:'var(--text-primary)',marginBottom:16}}>
          <span style={{color:'var(--accent)'}}>tele</span>cloud
        </p>
        <div style={{width:24,height:24,border:'2px solid var(--border)',borderTopColor:'var(--accent)',borderRadius:'50%',animation:'spin 0.8s linear infinite',margin:'0 auto'}} />
      </div>
    </div>
  );
  if (!user) return <LoginPage />;
  return <MediaGrid />;
}

export default function App() {
  return (
    <AuthProvider>
      <Inner />
    </AuthProvider>
  );
}
