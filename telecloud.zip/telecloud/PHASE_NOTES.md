# TeleCloud Professionalization Notes

## Phase 0 - Baseline Protection

- Original extracted project left untouched under `telecloud_inspect/stable/telecloud-electron`.
- Active development copy created under `telecloud_work`.
- Baseline app shape:
  - Electron starts the FastAPI backend on `127.0.0.1:8765`.
  - React/Vite frontend talks to the local backend.
  - Core flows: Telegram login, channels, media listing, thumbnails, upload, download, video cache/play.

## Phase 1 - Safe API/Auth Cleanup

- Added a shared frontend API config at `frontend/src/api/client.js`.
- Removed hard-coded Telegram API ID/hash usage from the login UI.
- Login screen now sends only phone/code to the backend.
- Backend auth accepts the new phone/code-only requests and resolves Telegram API credentials from `.env`.
- Backend still accepts optional `api_id`/`api_hash` in auth requests for backward compatibility.
- Cleaned visible login screen Turkish text and kept the existing layout/behavior.

## Phase 1 Checks

- Frontend dependency install completed in `frontend`.
- Frontend production build completed successfully with `npm.cmd run build`.
- Python is not available in PATH, but LibreOffice's bundled Python parsed `backend/app.py` successfully with `py_compile`.
- Backend runtime smoke test was not executed yet because the project backend virtualenv is not installed.
- Live smoke setup check: no backend `.venv` was found and port `127.0.0.1:8765` was not listening.

## Phase 2 - UI Speed and Responsiveness

- Improved `MediaCard` thumbnail behavior:
  - Thumbnail cache key now includes channel id and message id, avoiding collisions across channels.
  - In-flight thumbnail requests are deduplicated.
  - Thumbnail preloading starts earlier before cards enter the viewport.
  - Images use lazy loading and async decoding.
  - Card rendering is memoized and more layout-contained for smoother grids.
- Improved `MediaGrid` request handling:
  - Stale media fetches no longer overwrite newer channel/filter/search results.
  - Infinite scroll starts loading earlier.
  - Search debounce shortened slightly for a faster feel.
- Cleaned visible Turkish text in `Sidebar`, `Toolbar`, and `MediaGrid`.
- Frontend production build completed successfully after these changes.

## Phase 3 - Video Cache Experience

- Added `frontend/src/api/videoApi.js` for video cache/status/play API helpers.
- Video cards now check cache status when they enter the preload zone.
- Video cards show visible badges for ready and in-progress cache states.
- Reworked the video viewer cache flow:
  - Existing cached videos open directly from `/video/play`.
  - In-progress videos show progress and keep polling.
  - Missing cache starts automatically.
  - Cache/status failures now show a clear error state.
  - Added a "Tekrar dene" action for failed video cache starts.
- Cleaned viewer text and download labels.
- Frontend production build completed successfully after these changes.

## Phase 4 - Upload and Download Reliability

- Completed Electron download bridge:
  - Added `electronAPI.saveFile` in `electron/preload.js`.
  - Added `save-file` IPC handler in `electron/main.js`.
  - Desktop downloads now use a native save dialog when available.
  - Browser/fallback download behavior remains in place.
- Improved backend upload memory behavior:
  - Uploads are now written to a temporary file in 1 MB chunks.
  - The endpoint no longer reads the whole uploaded file into memory before sending to Telegram.
  - Returned upload size is tracked from streamed chunks.
  - Filenames are normalized with `Path(...).name` before creating temp files.
- Checks:
  - Frontend production build completed successfully.
  - Electron `main.js` and `preload.js` passed `node --check`.
  - `backend/app.py` passed Python `py_compile` with the available bundled Python.

## Phase 5 - Backend Stability and Cache Maintenance

- Added cache accounting helpers in `backend/app.py`.
- Added authenticated cache status endpoint:
  - `GET /system/cache/status`
  - Returns file counts and byte totals for thumbnails, videos, photos, files, and metadata.
- Added authenticated cache cleanup endpoint:
  - `POST /system/cache/cleanup`
  - Can clean the current user's thumbnail, video, and metadata cache.
  - Supports `older_than_days` so future UI can clean only stale cache.
  - Includes failed temp thumbnail/video cache files for the current user.
- Improved `/health` with `active_video_downloads`.
- Check: `backend/app.py` passed Python `py_compile`.
