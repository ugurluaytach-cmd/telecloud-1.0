@echo off
cd /d "%~dp0"
title TeleCloud Setup
echo =========================================
echo  TeleCloud - Kurulum
echo =========================================
echo.
python --version >nul 2>&1
if errorlevel 1 ( echo [HATA] Python yok - python.org/downloads & pause & exit /b 1 )
node --version >nul 2>&1
if errorlevel 1 ( echo [HATA] Node.js yok - nodejs.org/en/download & pause & exit /b 1 )
echo [OK] Python ve Node.js mevcut

echo [..] Backend kutuphane yukleniyor...
cd backend
if not exist ".venv" python -m venv .venv
call .venv\Scripts\activate.bat
pip install --quiet fastapi uvicorn sqlalchemy aiosqlite python-dotenv cryptography telethon aiofiles python-multipart
echo [OK] Backend hazir
cd ..

echo [..] Frontend derleniyor...
cd frontend
call npm install --silent
call npm run build
cd ..
echo [OK] Frontend derlendi

echo [..] Electron kuruluyor...
call npm install --silent
echo [OK] Electron kuruldu

echo.
echo Kurulum tamamlandi! start.bat ile baslatin.
pause
