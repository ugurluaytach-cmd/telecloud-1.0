const { app, BrowserWindow, ipcMain, dialog, Tray, Menu, nativeImage } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

let mainWindow;
let backendProcess;
let tray;

function startBackend() {
  const backendDir = path.join(__dirname, '..', 'backend');
  const pythonExe  = path.join(backendDir, '.venv', 'Scripts', 'python.exe');

  backendProcess = spawn(pythonExe, [
    '-m', 'uvicorn', 'app:app',
    '--host', '127.0.0.1',
    '--port', '8765'
  ], { cwd: backendDir });

  backendProcess.stdout.on('data', d => console.log('Backend:', d.toString().trim()));
  backendProcess.stderr.on('data', d => console.log('Backend:', d.toString().trim()));
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    title: 'TeleCloud',
    backgroundColor: '#0c0c0b',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    show: false,
  });

  // Yuklenme ekrani
  mainWindow.loadURL('data:text/html,<html style="background:#0c0c0b;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;font-family:serif"><div style="color:#c9a96e;font-size:48px;font-weight:300"><span style="color:#e8e6df">tele</span>cloud</div></html>');
  mainWindow.show();

  // Backend hazir olana kadar 4sn bekle sonra yukle
  setTimeout(() => {
    mainWindow.loadURL('http://localhost:8765');
  }, 4000);

  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(() => {
  startBackend();
  createWindow();
});

app.on('window-all-closed', () => {
  if (backendProcess) backendProcess.kill();
  app.quit();
});

app.on('before-quit', () => {
  if (backendProcess) backendProcess.kill();
});

ipcMain.handle('select-files', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile', 'multiSelections'],
    filters: [
      { name: 'Medya', extensions: ['jpg','jpeg','png','gif','mp4','mov','avi','mkv','mp3','wav','pdf','zip'] },
      { name: 'Tum Dosyalar', extensions: ['*'] }
    ]
  });
  return result.canceled ? [] : result.filePaths;
});

ipcMain.handle('save-file', async (_event, payload = {}) => {
  const { url, filename = 'download' } = payload;
  if (!url) return { success: false, error: 'URL eksik' };

  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: filename,
    buttonLabel: 'Kaydet',
  });
  if (result.canceled || !result.filePath) return { canceled: true };

  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const buffer = Buffer.from(await response.arrayBuffer());
    await fs.promises.writeFile(result.filePath, buffer);
    return { success: true, path: result.filePath };
  } catch (error) {
    return { success: false, error: error.message };
  }
});
