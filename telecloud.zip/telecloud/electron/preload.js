const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  selectFiles: () => ipcRenderer.invoke('select-files'),
  saveFile: payload => ipcRenderer.invoke('save-file', payload),
  isElectron: true,
});
