# TeleCloud Final Test Checklist

## Kurulum

- `setup.bat` calistir.
- `backend/.env` icinde `TG_API_ID` ve `TG_API_HASH` dolu oldugunu kontrol et.
- `start.bat` ile uygulamayi baslat.

## Temel Akis

- Telefon numarasi ile SMS kodu iste.
- Kod ile giris yap.
- Kanallar/depolar listeleniyor mu kontrol et.
- Kayitli Mesajlar medyalarini listele.

## Medya

- Thumbnail'ler sirayla yukleniyor mu kontrol et.
- Arama ve medya turu filtrelerini dene.
- Foto ac, kapat, sonraki/onceki gezinmeyi dene.

## Video Cache

- Daha once cache'de olmayan bir video ac.
- Progress ekrani gorunuyor mu kontrol et.
- Video hazir olunca otomatik oynuyor mu kontrol et.
- Ayni videoyu tekrar acinca daha hizli aciliyor mu kontrol et.

## Upload / Download

- Kucuk fotograf yukle.
- Zip veya belge yukle.
- Viewer'dan indir butonunu dene.
- Electron'da kaydet penceresi aciliyor mu kontrol et.

## Cache

- Backend acikken `/health` durumunun calistigini kontrol et.
- Uygulamayi kapatip acinca cache'li video/thumbnail davranisini tekrar dene.
