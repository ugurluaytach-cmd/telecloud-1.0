@echo off
cd /d "%~dp0"
title TeleCloud
echo TeleCloud baslatiliyor...
npx electron .
