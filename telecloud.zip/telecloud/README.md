# telecloud

A Google Photos-style desktop media viewer that uses **Telegram as cloud storage**.  
Browse, stream, upload, and download your photos, videos, audio, and documents — all stored in your own Telegram channels — from a native desktop app.

![Platform](https://img.shields.io/badge/platform-Windows-blue)
![Electron](https://img.shields.io/badge/Electron-28-47848F?logo=electron)
![React](https://img.shields.io/badge/React-18-61DAFB?logo=react)
![FastAPI](https://img.shields.io/badge/FastAPI-0.110-009688?logo=fastapi)
![License](https://img.shields.io/badge/license-MIT-green)

---

## What it does

Telegram gives every account unlimited cloud storage for media files. TeleCloud turns that storage into a proper media library:

- **Grid browser** — infinite-scroll thumbnail grid, just like Google Photos
- **Multi-channel** — browse Saved Messages or any channel you own; create new storage channels from inside the app
- **Filter by type** — Photos / Videos / Audio / Documents tabs in the sidebar
- **Search** — full-text search across media in the active channel
- **Lightbox viewer** — keyboard-navigable photo viewer with prev/next
- **Video player** — local cache → stream pipeline; videos are cached first, then played with a built-in player
- **Upload** — drag-and-drop or file picker; chunked upload to Telegram (1 MB chunks, no memory spike)
- **Download** — native OS save dialog via Electron IPC
- **Cache management** — view cache sizes (thumbnails, videos, photos, files, metadata) and clean up stale cache from the UI

---

## Architecture

```
┌─────────────────────────────────────────────┐
│                   Electron                  │
│  ┌──────────────────────────────────────┐   │
│  │     React + Vite  (frontend)         │   │
│  │  MediaGrid · Lightbox · VideoPlayer  │   │
│  └───────────────┬──────────────────────┘   │
│                  │ HTTP  localhost:8765      │
│  ┌───────────────▼──────────────────────┐   │
│  │   FastAPI + Telethon  (backend)      │   │
│  │   SQLite session store (aiosqlite)   │   │
│  └───────────────┬──────────────────────┘   │
└──────────────────┼──────────────────────────┘
                   │ MTProto
            ┌──────▼──────┐
            │   Telegram  │
            └─────────────┘
```

- **Electron** spawns the FastAPI backend on `127.0.0.1:8765` and loads `http://localhost:8765` as its window.
- **Backend** (`backend/app.py`) authenticates with Telegram via [Telethon](https://github.com/LonamiWebs/Telethon), serves the React build as static files, and exposes a REST API.
- **Frontend** (`frontend/`) is a Vite + React app built to `frontend/dist/` and served by FastAPI.
- **Telegram sessions** are encrypted with Fernet (AES-128) and stored in a local SQLite database.

---

## Requirements

| Dependency | Version | Notes |
|---|---|---|
| Python | 3.10 + | Must be in PATH |
| Node.js | 18 + | Must be in PATH |
| Telegram account | — | Any personal account |

---

## Installation

### Step 1 — Get your Telegram API credentials

Every user needs their own API credentials. This is free and takes about 2 minutes.

1. Open [my.telegram.org/apps](https://my.telegram.org/apps) in a browser
2. Log in with your Telegram phone number (you'll receive an SMS code)
3. Click **"Create application"**
4. Fill in any name and short name (e.g. `TeleCloud` / `tc`) — the values don't matter
5. Click **Save changes**
6. You will see your **App api_id** (a number) and **App api_hash** (a hex string) — copy both

> These credentials are tied to your Telegram account and stay private on your machine. Never share them.

---

### Step 2 — Configure the environment file

Open `backend/.env` in any text editor and fill in the four placeholder values:

```env
# Generate a random hex string for each of these two keys:
#   python -c "import secrets; print(secrets.token_hex(32))"
SECRET_KEY=paste_your_random_hex_here
SESSION_ENCRYPT_KEY=paste_another_random_hex_here

DATABASE_URL=sqlite+aiosqlite:///./data/telecloud.db
ACCESS_TOKEN_TTL=3600
REFRESH_TOKEN_TTL=2592000
ALLOWED_ORIGINS=http://localhost:3000
DB_ECHO=false
THUMBNAIL_DIR=./thumbnails

# Paste the credentials you got from my.telegram.org/apps
TG_API_ID=12345678
TG_API_HASH=abcdef1234567890abcdef1234567890
```

To generate the random keys, open a terminal and run:

```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

Run it twice — once for `SECRET_KEY`, once for `SESSION_ENCRYPT_KEY`.

---

### Step 3 — Run setup and start

```bat
:: One-time setup (creates Python venv, installs dependencies, builds the frontend)
setup.bat

:: Launch the app
start.bat
```

---

### Step 4 — Log in

1. The app opens with a login screen
2. Enter your Telegram phone number (with country code, e.g. `+905001234567`)
3. Telegram sends you a confirmation code — enter it in the app
4. You're in. Your **Saved Messages** channel is selected by default

---

## Usage

| Action | How |
|---|---|
| Browse media | Click a channel in the left sidebar |
| Filter by type | Use the Photos / Videos / Audio / Documents tabs |
| Open a photo | Click any thumbnail — opens the lightbox |
| Navigate lightbox | Arrow keys or prev/next buttons |
| Play a video | Click the thumbnail — it caches locally first, then plays |
| Upload files | Click the upload button in the toolbar or drag-and-drop |
| Download a file | Open it in the viewer, click Download — native save dialog |
| Create a channel | Click "New Channel" in the sidebar |
| Clean up cache | Settings → Cache → Clean up |

---

## Project structure

```
telecloud/
├── backend/
│   ├── app.py            # FastAPI app — all endpoints, Telegram logic, cache
│   ├── setup_env.py      # Environment validation helper
│   └── .env              # Your local config (never commit this)
├── electron/
│   ├── main.js           # Electron main process, IPC handlers, backend spawn
│   └── preload.js        # Context bridge (select-files, save-file)
├── frontend/
│   ├── src/
│   │   ├── api/          # client.js, mediaApi.js, videoApi.js
│   │   ├── components/   # MediaGrid, MediaCard, Sidebar, Toolbar,
│   │   │                 # Lightbox, VideoPlayer, Viewer, LoginPage
│   │   ├── hooks/        # useAuth, useInfiniteMedia
│   │   └── styles/       # globals.css
│   ├── dist/             # Production build (generated by setup.bat)
│   └── vite.config.js
├── package.json          # Electron entry point
├── setup.bat             # One-time install script
└── start.bat             # Launch script
```

---

## API reference

All endpoints are served by the FastAPI backend on `http://127.0.0.1:8765`.  
Authenticated endpoints require an `Authorization: Bearer <token>` header.

| Method | Path | Auth | Description |
|---|---|---|---|
| `POST` | `/auth/send_code` | — | Request Telegram SMS code |
| `POST` | `/auth/verify` | — | Verify code, get access token |
| `GET` | `/auth/me` | ✓ | Current user info |
| `GET` | `/storage/info` | ✓ | Telegram storage usage |
| `GET` | `/channels` | ✓ | List channels |
| `POST` | `/channels/create` | ✓ | Create a new channel |
| `GET` | `/media/channel/{id}` | ✓ | Media in a channel (paginated) |
| `GET` | `/media` | ✓ | Media search |
| `GET` | `/thumbnail/{channel_id}/{msg_id}` | ✓ | Thumbnail (cached) |
| `GET` | `/stream/{channel_id}/{msg_id}` | ✓ | Streaming download |
| `GET` | `/video/status/{channel_id}/{msg_id}` | ✓ | Video cache status |
| `POST` | `/video/cache/{channel_id}/{msg_id}` | ✓ | Start video caching |
| `GET` | `/video/play/{channel_id}/{msg_id}` | ✓ | Serve cached video |
| `GET` | `/download/{channel_id}/{msg_id}` | ✓ | Download file |
| `POST` | `/upload` | ✓ | Upload file to Telegram (chunked) |
| `GET` | `/health` | — | Backend health + active downloads |
| `GET` | `/system/cache/status` | ✓ | Cache file counts and sizes |
| `POST` | `/system/cache/cleanup` | ✓ | Clean stale cache |

---

## Known limitations

- **Telethon rate limits** — Telegram's MTProto API throttles heavy media requests. Thumbnail loading is intentionally rate-limited (max 5 concurrent downloads) to avoid flood waits.
- **Windows only** — The setup scripts are `.bat` files and the backend process path assumes `Scripts/python.exe` (Windows venv layout). Linux/macOS support would require minor changes to `electron/main.js` and the setup scripts.
- **No packaged installer** — The app runs from source. `electron-builder` packaging is a possible future addition.
- **Single user** — One Telegram account per app instance (by design — it's a personal media viewer).

---

## Tech stack

| Layer | Technology |
|---|---|
| Desktop shell | Electron 28 |
| Frontend | React 18, Vite |
| Backend | FastAPI, Uvicorn, aiosqlite, SQLAlchemy (async) |
| Telegram client | Telethon (MTProto) |
| Session encryption | Python `cryptography` — Fernet (AES-128-CBC) |
| Local database | SQLite |

---

## Contributing

Pull requests are welcome. For larger changes, please open an issue first to discuss what you'd like to change.

Please run the frontend build before submitting a PR:
```bash
cd frontend && npm run build
```

---

## License

MIT — see [LICENSE](LICENSE) for details.

---

> **Disclaimer:** This project is not affiliated with Telegram. Using Telegram as a file storage backend is subject to [Telegram's Terms of Service](https://telegram.org/tos). Use responsibly.
