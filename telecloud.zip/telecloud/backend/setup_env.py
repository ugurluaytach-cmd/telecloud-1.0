import secrets
import os
from pathlib import Path

BASE = Path(__file__).parent
env_file = BASE / ".env"

if env_file.exists():
    print(".env zaten var, atlanıyor.")
else:
    key1 = secrets.token_hex(32)
    key2 = secrets.token_hex(32)
    env_file.write_text(
        f"SECRET_KEY={key1}\n"
        f"SESSION_ENCRYPT_KEY={key2}\n"
        f"DATABASE_URL=sqlite+aiosqlite:///./data/telecloud.db\n"
        f"ACCESS_TOKEN_TTL=3600\n"
        f"REFRESH_TOKEN_TTL=2592000\n"
        f"ALLOWED_ORIGINS=http://localhost:3000\n"
        f"DB_ECHO=false\n"
        f"THUMBNAIL_DIR=./thumbnails\n"
        f"TG_API_ID=BURAYA_YAZIN\n"
        f"TG_API_HASH=BURAYA_YAZIN\n"
    )
    print(".env olusturuldu.")
