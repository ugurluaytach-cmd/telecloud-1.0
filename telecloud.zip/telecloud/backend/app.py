import os, asyncio, secrets, base64, logging, mimetypes, json, time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, HTMLResponse, FileResponse, Response
from fastapi.staticfiles import StaticFiles
from cryptography.fernet import Fernet
from pydantic import BaseModel
from sqlalchemy import BigInteger, DateTime, String, Text, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite+aiosqlite:///./data/telecloud.db")
SESSION_KEY  = os.environ.get("SESSION_ENCRYPT_KEY", secrets.token_hex(32))
STREAM_CHUNK = 512 * 1024
TG_API_ID   = os.environ.get("TG_API_ID", "").strip()
TG_API_HASH = os.environ.get("TG_API_HASH", "").strip()

_raw    = bytes.fromhex(SESSION_KEY.ljust(64,"0")[:64])
_fernet = Fernet(base64.urlsafe_b64encode(_raw))

engine    = create_async_engine(DATABASE_URL, connect_args={"check_same_thread": False})
DBSession = async_sessionmaker(engine, expire_on_commit=False)

class Base(DeclarativeBase): pass

class TelegramUser(Base):
    __tablename__ = "telegram_users"
    id:          Mapped[int] = mapped_column(primary_key=True)
    tg_id:       Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    phone:       Mapped[str] = mapped_column(String(20))
    first_name:  Mapped[str] = mapped_column(String(100))
    session_enc: Mapped[str] = mapped_column(Text)
    api_id:      Mapped[int] = mapped_column(BigInteger)
    api_hash:    Mapped[str] = mapped_column(String(64))
    created_at:  Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

_tg_clients  = {}
_sessions    = {}
_pending     = {}
_thumb_locks = {}  # thumbnail race condition onleme
_thumb_sem   = asyncio.Semaphore(5)  # max 5 esz zamanli thumbnail indirme

# ── Uygulama ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    Path("data").mkdir(exist_ok=True)
    Path("cache/thumbnails").mkdir(parents=True, exist_ok=True)
    Path("cache/photos").mkdir(parents=True, exist_ok=True)
    Path("cache/videos").mkdir(parents=True, exist_ok=True)
    Path("cache/files").mkdir(parents=True, exist_ok=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("TeleCloud hazir - port 8765")
    yield
    for c in _tg_clients.values():
        try: await c.disconnect()
        except: pass

app = FastAPI(title="TeleCloud", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                  allow_methods=["*"], allow_headers=["*"])

# ── Yardımcı: token → client ──────────────────────────────────────────────────
# Bu fonksiyon tum endpoint'lerden ONCE tanimlanmali

async def _client(token: str):
    """Token'dan Telegram client ve user_id döndürür."""
    uid = _sessions.get(token)
    if not uid:
        raise HTTPException(401, "Giris gerekli")
    client = _tg_clients.get(uid)
    if not client:
        async with DBSession() as db:
            r = await db.execute(select(TelegramUser).where(TelegramUser.id == uid))
            u = r.scalar_one_or_none()
            if not u:
                raise HTTPException(401, "Kullanici bulunamadi")
            from telethon import TelegramClient
            from telethon.sessions import StringSession
            dec    = _fernet.decrypt(u.session_enc.encode()).decode()
            client = TelegramClient(StringSession(dec), u.api_id, u.api_hash)
            await client.connect()
            _tg_clients[uid] = client
    return client, uid

def _token_from(request: Request, token: str = "") -> str:
    """Header veya query param'dan token al."""
    return token or request.headers.get("Authorization","").replace("Bearer ","")

# ── Metadata cache ────────────────────────────────────────────────────────────

def _meta_path(uid: int, channel_id: str) -> Path:
    return Path(f"data/meta_{uid}_{channel_id}.json")

def _meta_load(uid: int, channel_id: str) -> dict:
    """Lokal cache'den metadata yukle. Yoksa bos dict doner."""
    p = _meta_path(uid, channel_id)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def _meta_save(uid: int, channel_id: str, data: dict) -> None:
    """Metadata'yi atomik yaz."""
    p   = _meta_path(uid, channel_id)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    tmp.rename(p)


CACHE_DIRS = {
    "thumbnails": Path("cache/thumbnails"),
    "videos": Path("cache/videos"),
    "photos": Path("cache/photos"),
    "files": Path("cache/files"),
}

def _file_count_and_size(root: Path) -> dict:
    count = 0
    size = 0
    if not root.exists():
        return {"files": 0, "bytes": 0}
    for p in root.rglob("*"):
        if p.is_file():
            try:
                count += 1
                size += p.stat().st_size
            except OSError:
                pass
    return {"files": count, "bytes": size}

def _cache_summary() -> dict:
    parts = {name: _file_count_and_size(path) for name, path in CACHE_DIRS.items()}
    meta_files = list(Path("data").glob("meta_*.json")) if Path("data").exists() else []
    meta_bytes = 0
    for p in meta_files:
        try:
            meta_bytes += p.stat().st_size
        except OSError:
            pass
    parts["metadata"] = {"files": len(meta_files), "bytes": meta_bytes}
    return {
        "total": {
            "files": sum(v["files"] for v in parts.values()),
            "bytes": sum(v["bytes"] for v in parts.values()),
        },
        "parts": parts,
    }

def _cleanup_files(paths: list[Path], older_than_days: Optional[int]) -> dict:
    removed = 0
    bytes_removed = 0
    cutoff = None
    if older_than_days is not None:
        cutoff = time.time() - max(0, older_than_days) * 86400

    for p in paths:
        if not p.is_file():
            continue
        try:
            stat = p.stat()
            if cutoff is not None and stat.st_mtime > cutoff:
                continue
            bytes_removed += stat.st_size
            p.unlink()
            removed += 1
        except OSError:
            pass
    return {"files_removed": removed, "bytes_removed": bytes_removed}


# ── Auth ──────────────────────────────────────────────────────────────────────

class SendCodeIn(BaseModel):
    phone:    str
    api_id:   Optional[int] = None
    api_hash: Optional[str] = None

class VerifyIn(BaseModel):
    phone:    str
    code:     str
    api_id:   Optional[int] = None
    api_hash: Optional[str] = None

class CacheCleanupIn(BaseModel):
    thumbnails: bool = False
    videos: bool = False
    metadata: bool = False
    older_than_days: Optional[int] = None

def _telegram_credentials(api_id: Optional[int] = None, api_hash: Optional[str] = None) -> tuple[int, str]:
    resolved_id = api_id or (int(TG_API_ID) if TG_API_ID.isdigit() else None)
    resolved_hash = api_hash or TG_API_HASH
    if not resolved_id or not resolved_hash or resolved_hash == "BURAYA_YAZIN":
        raise HTTPException(500, "Telegram API bilgileri backend .env icinde eksik")
    return resolved_id, resolved_hash

@app.post("/auth/send_code")
async def send_code(body: SendCodeIn):
    from telethon import TelegramClient
    from telethon.sessions import StringSession
    api_id, api_hash = _telegram_credentials(body.api_id, body.api_hash)
    client = TelegramClient(StringSession(), api_id, api_hash)
    await client.connect()
    result = await client.send_code_request(body.phone)
    _pending[body.phone] = {
        "client": client,
        "hash":   result.phone_code_hash,
        "api_id": api_id,
        "api_hash": api_hash,
    }
    return {"detail": "SMS gonderildi"}

@app.post("/auth/verify")
async def verify(body: VerifyIn):
    p = _pending.get(body.phone)
    if not p:
        raise HTTPException(400, "Once /auth/send_code cagrisi yapin")
    client = p["client"]
    api_id, api_hash = _telegram_credentials(body.api_id or p["api_id"], body.api_hash or p["api_hash"])
    try:
        await client.sign_in(body.phone, body.code, phone_code_hash=p["hash"])
    except Exception as e:
        raise HTTPException(400, f"Kod hatasi: {e}")

    me          = await client.get_me()
    session_str = client.session.save()
    enc         = _fernet.encrypt(session_str.encode()).decode()

    async with DBSession() as db:
        r = await db.execute(select(TelegramUser).where(TelegramUser.tg_id == me.id))
        tg_user = r.scalar_one_or_none()
        if not tg_user:
            tg_user = TelegramUser(
                tg_id=me.id, phone=body.phone,
                first_name=me.first_name or "User",
                session_enc=enc, api_id=api_id, api_hash=api_hash,
            )
            db.add(tg_user)
        else:
            tg_user.session_enc = enc
            tg_user.api_id = api_id
            tg_user.api_hash = api_hash
        await db.commit()
        await db.refresh(tg_user)

    token = secrets.token_hex(32)
    _sessions[token]       = tg_user.id
    _tg_clients[tg_user.id] = client
    del _pending[body.phone]

    return {
        "token": token,
        "user": {"id": tg_user.id, "name": tg_user.first_name, "phone": tg_user.phone},
    }

@app.get("/auth/me")
async def me(request: Request):
    client, uid = await _client(_token_from(request))
    me = await client.get_me()
    return {"id": uid, "name": me.first_name, "phone": me.phone}

# ── Depolama bilgisi ──────────────────────────────────────────────────────────

@app.get("/storage/info")
async def storage_info(request: Request):
    client, uid = await _client(_token_from(request))
    me = await client.get_me()
    return {
        "name":    me.first_name,
        "phone":   me.phone,
        "premium": getattr(me, "premium", False),
        "storage_limit_gb": 4 if getattr(me, "premium", False) else 2,
    }

# ── Kanal yönetimi ────────────────────────────────────────────────────────────

class CreateChannelIn(BaseModel):
    name: str

@app.get("/channels")
async def list_channels(request: Request):
    client, uid = await _client(_token_from(request))
    from telethon.tl.types import Channel
    channels = [{"id": "me", "name": "Kayitli Mesajlar", "is_creator": True}]
    async for dialog in client.iter_dialogs():
        if isinstance(dialog.entity, Channel) and dialog.entity.creator:
            channels.append({
                "id":         dialog.entity.id,
                "name":       dialog.entity.title,
                "is_creator": True,
            })
    return {"channels": channels}

@app.post("/channels/create")
async def create_channel(body: CreateChannelIn, request: Request):
    client, uid = await _client(_token_from(request))
    from telethon.tl.functions.channels import CreateChannelRequest
    result  = await client(CreateChannelRequest(
        title=body.name, about=f"TeleCloud: {body.name}", megagroup=False,
    ))
    channel = result.chats[0]
    return {"id": channel.id, "name": channel.title}

# ── Medya listeleme ───────────────────────────────────────────────────────────

def _parse_msg(msg, channel_id="me"):
    """Telegram mesajından medya bilgisi çıkar. None → atla."""
    from telethon.tl.types import MessageMediaPhoto, MessageMediaDocument
    from telethon.tl.types import DocumentAttributeFilename, DocumentAttributeVideo, DocumentAttributeAudio

    if isinstance(msg.media, MessageMediaPhoto):
        return {
            "id": msg.id, "channel_id": channel_id,
            "filename": f"photo_{msg.id}.jpg",
            "media_type": "PHOTO", "mime_type": "image/jpeg", "file_size": 0,
            "date": msg.date.isoformat() if msg.date else None,
            "thumb_url":  f"/thumbnail/{channel_id}/{msg.id}",
            "stream_url": f"/stream/{channel_id}/{msg.id}",
        }
    if isinstance(msg.media, MessageMediaDocument):
        doc   = msg.media.document
        mime  = doc.mime_type or "application/octet-stream"
        fname = f"file_{msg.id}"
        mtype = "DOCUMENT"
        for attr in doc.attributes:
            if isinstance(attr, DocumentAttributeFilename): fname = attr.file_name
            if isinstance(attr, DocumentAttributeVideo):    mtype = "VIDEO"
            if isinstance(attr, DocumentAttributeAudio):    mtype = "AUDIO"
        if mime.startswith("image/"): mtype = "PHOTO"
        elif mime.startswith("video/"): mtype = "VIDEO"
        elif mime.startswith("audio/"): mtype = "AUDIO"
        return {
            "id": msg.id, "channel_id": channel_id,
            "filename": fname, "media_type": mtype,
            "mime_type": mime, "file_size": doc.size,
            "date": msg.date.isoformat() if msg.date else None,
            "thumb_url":  f"/thumbnail/{channel_id}/{msg.id}",
            "stream_url": f"/stream/{channel_id}/{msg.id}",
        }
    return None

@app.get("/media/channel/{channel_id}")
async def list_channel_media(
    channel_id: str, request: Request,
    page: int = 1, page_size: int = 50,
    media_type: Optional[str] = None,
    search: Optional[str] = None,
    refresh: bool = False,
):
    client, uid = await _client(_token_from(request))
    entity = "me" if channel_id == "me" else int(channel_id)

    # Cache'den yukle (refresh=True ise atla)
    meta = {} if refresh else _meta_load(uid, channel_id)

    # Cache yoksa veya 10 dakikadan eskiyse Telegram'dan cek
    cache_age = time.time() - meta.get("_fetched_at", 0)
    if not meta or cache_age > 600 or refresh:
        all_items = []
        async for msg in client.iter_messages(entity):
            if not msg.media: continue
            info = _parse_msg(msg, channel_id)
            if info:
                all_items.append(info)
        meta = {"_fetched_at": time.time(), "items": all_items}
        _meta_save(uid, channel_id, meta)

    all_items = meta.get("items", [])

    # Filtrele
    filtered = []
    for info in all_items:
        if media_type and info["media_type"] != media_type: continue
        if search and search.lower() not in info["filename"].lower(): continue
        filtered.append(info)

    # Sayfalama
    offset  = (page - 1) * page_size
    results = filtered[offset: offset + page_size]

    return {"page": page, "channel_id": channel_id, "items": results,
            "total": len(filtered), "cached": cache_age < 600}

# /media endpoint'i — geriye dönük uyumluluk için
@app.get("/media")
async def list_media(request: Request, page: int = 1, page_size: int = 50,
                     media_type: Optional[str] = None, search: Optional[str] = None):
    return await list_channel_media("me", request, page, page_size, media_type, search)

# ── Thumbnail ─────────────────────────────────────────────────────────────────

@app.get("/thumbnail/{channel_id}/{msg_id}")
async def thumbnail(channel_id: str, msg_id: int, request: Request, token: str = ""):
    token       = _token_from(request, token)
    client, uid = await _client(token)
    entity      = "me" if channel_id == "me" else int(channel_id)

    # Cache klasoru: cache/thumbnails/
    cache_dir = Path("cache/thumbnails")
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache = cache_dir / f"{uid}_{channel_id}_{msg_id}.jpg"

    # Eski thumbnails/ klasorunden tasima
    old_cache = Path(f"thumbnails/{uid}_{channel_id}_{msg_id}.jpg")
    if not cache.exists() and old_cache.exists():
        import shutil; shutil.copy2(str(old_cache), str(cache))

    # Cache varsa hemen don — Telegram'a gitmez
    if cache.exists() and cache.stat().st_size > 0:
        return FileResponse(str(cache), media_type="image/jpeg",
                            headers={"Cache-Control": "public, max-age=604800"})

    # Race condition onleme: ayni thumbnail icin tek istek
    lock_key = f"{uid}_{channel_id}_{msg_id}"
    if lock_key not in _thumb_locks:
        _thumb_locks[lock_key] = asyncio.Lock()

    async with _thumb_locks[lock_key]:
        # Lock alindiktan sonra tekrar kontrol (baska coroutine indirmis olabilir)
        if cache.exists() and cache.stat().st_size > 0:
            return FileResponse(str(cache), media_type="image/jpeg",
                                headers={"Cache-Control": "public, max-age=604800"})
        try:
            msg = await client.get_messages(entity, ids=msg_id)
            if not msg or not msg.media:
                raise HTTPException(404, "Medya bulunamadi")

            async with _thumb_sem:  # max 5 esz zamanli Telegram istegi
                data = await client.download_media(msg, bytes, thumb=-1)
                if not data:
                    data = await client.download_media(msg, bytes)
            if not data:
                raise HTTPException(404, "Thumbnail indirilemedi")

            # Atomik yazma: once temp dosyaya yaz, sonra rename
            tmp = cache_dir / f".tmp_{uid}_{channel_id}_{msg_id}.jpg"
            tmp.write_bytes(data[:200_000])
            tmp.rename(cache)  # Atomik - bozuk dosya kalmaz

        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(500, str(e))
        finally:
            # Lock'u temizle (bellek tasarrufu)
            _thumb_locks.pop(lock_key, None)

    if cache.exists():
        return FileResponse(str(cache), media_type="image/jpeg",
                            headers={"Cache-Control": "public, max-age=604800"})
    raise HTTPException(404, "Thumbnail olusturulamadi")


# ── Stream ────────────────────────────────────────────────────────────────────

@app.get("/stream/{channel_id}/{msg_id}")
async def stream(channel_id: str, msg_id: int, request: Request, token: str = ""):
    token  = _token_from(request, token)
    client, uid = await _client(token)
    entity = "me" if channel_id == "me" else int(channel_id)

    msg = await client.get_messages(entity, ids=msg_id)
    if not msg or not msg.media:
        raise HTTPException(404, "Medya bulunamadi")

    from telethon.tl.types import MessageMediaPhoto, MessageMediaDocument

    if isinstance(msg.media, MessageMediaDocument):
        total = msg.media.document.size
        mime  = msg.media.document.mime_type or "application/octet-stream"
    elif isinstance(msg.media, MessageMediaPhoto):
        total = 0
        mime  = "image/jpeg"
    else:
        raise HTTPException(415, "Desteklenmeyen medya")

    # Fotograf ve kucuk dosyalar: tamamen indir
    if total == 0 or total < 20 * 1024 * 1024:
        data = await client.download_media(msg, bytes)
        if not data:
            raise HTTPException(500, "Indirme basarisiz")
        actual = len(data)
        rng = request.headers.get("Range", "")
        if rng:
            try:
                parts = rng.replace("bytes=", "").split("-")
                s = int(parts[0]) if parts[0] else 0
                e = int(parts[1]) if len(parts) > 1 and parts[1] else actual - 1
                e = min(e, actual - 1)
                return Response(
                    content=data[s:e+1], status_code=206, media_type=mime,
                    headers={
                        "Content-Range":  f"bytes {s}-{e}/{actual}",
                        "Content-Length": str(e - s + 1),
                        "Accept-Ranges":  "bytes",
                    }
                )
            except Exception:
                pass
        return Response(
            content=data, status_code=200, media_type=mime,
            headers={"Content-Length": str(actual), "Accept-Ranges": "bytes"}
        )

    # Buyuk dosyalar: Telethon offset ile streaming
    rng   = request.headers.get("Range", "")
    start, end = 0, total - 1
    if rng:
        try:
            parts = rng.replace("bytes=", "").split("-")
            start = int(parts[0]) if parts[0] else 0
            end   = int(parts[1]) if len(parts) > 1 and parts[1] else total - 1
            start = max(0, min(start, total - 1))
            end   = max(start, min(end, total - 1))
        except Exception:
            pass

    length = end - start + 1

    # Chunk boyutunu Telethon'un kendi chunk'larıyla hizala
    # Telethon 512KB chunk kullanır, offset bu değerin katı olmalı
    CHUNK = 512 * 1024
    aligned_start = (start // CHUNK) * CHUNK

    async def gen():
        sent       = 0
        skip_bytes = start - aligned_start  # ilk chunk'ta atlanacak byte

        async for chunk in client.iter_download(
            msg.media,
            offset=aligned_start,
            chunk_size=CHUNK,
            request_size=CHUNK,
        ):
            if await request.is_disconnected():
                break

            # Ilk chunk'ta hizalama farkini atla
            if skip_bytes > 0:
                chunk      = chunk[skip_bytes:]
                skip_bytes = 0

            if sent >= length:
                break

            remaining = length - sent
            if len(chunk) > remaining:
                chunk = chunk[:remaining]

            yield chunk
            sent += len(chunk)

            if sent >= length:
                break

    return StreamingResponse(
        gen(),
        status_code=206 if rng else 200,
        media_type=mime,
        headers={
            "Content-Range":  f"bytes {start}-{end}/{total}",
            "Content-Length": str(length),
            "Accept-Ranges":  "bytes",
            "Cache-Control":  "no-cache",
        }
    )



# ── Video cache ───────────────────────────────────────────────────────────────

_video_downloads = {}

@app.get("/video/status/{channel_id}/{msg_id}")
async def video_status(channel_id: str, msg_id: int, request: Request, token: str = ""):
    token       = _token_from(request, token)
    client, uid = await _client(token)
    key         = f"{uid}_{channel_id}_{msg_id}"
    cache_dir   = Path("cache/videos")
    for ext in [".mp4",".mkv",".mov",".avi",".webm",".orig",".jpg"]:
        p = cache_dir / f"{key}{ext}"
        if p.exists() and p.stat().st_size > 0:
            return {"status": "ready"}
    if key in _video_downloads:
        return {"status": "downloading", "progress": _video_downloads[key]}
    return {"status": "none"}

@app.post("/video/cache/{channel_id}/{msg_id}")
async def video_cache_start(channel_id: str, msg_id: int, request: Request, token: str = ""):
    token       = _token_from(request, token)
    client, uid = await _client(token)
    entity      = "me" if channel_id == "me" else int(channel_id)
    key         = f"{uid}_{channel_id}_{msg_id}"
    cache_dir   = Path("cache/videos")

    if key in _video_downloads:
        return {"status": "already_downloading", "progress": _video_downloads[key]}

    for ext in [".mp4",".mkv",".mov",".avi",".webm",".orig",".jpg"]:
        p = cache_dir / f"{key}{ext}"
        if p.exists() and p.stat().st_size > 0:
            return {"status": "ready"}

    async def _download():
        _video_downloads[key] = 0
        try:
            msg = await client.get_messages(entity, ids=msg_id)
            if not msg or not msg.media: return
            from telethon.tl.types import MessageMediaDocument
            ext = ".mp4"
            total = 0
            if isinstance(msg.media, MessageMediaDocument):
                total = msg.media.document.size
                for attr in msg.media.document.attributes:
                    from telethon.tl.types import DocumentAttributeFilename
                    if isinstance(attr, DocumentAttributeFilename):
                        parts = attr.file_name.rsplit(".", 1)
                        if len(parts) == 2: ext = "." + parts[1].lower()
                        break
            cache_dir.mkdir(parents=True, exist_ok=True)
            tmp   = cache_dir / f".tmp_{key}{ext}"
            final = cache_dir / f"{key}{ext}"
            downloaded = 0
            with open(tmp, "wb") as f:
                async for chunk in client.iter_download(msg.media, chunk_size=512*1024):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        _video_downloads[key] = round(downloaded / total * 100, 1)
            tmp.rename(final)
            _video_downloads[key] = 100
        except Exception as e:
            logger.error("Video cache hatasi [%s]: %s", key, e)
        finally:
            await asyncio.sleep(5)
            _video_downloads.pop(key, None)

    asyncio.create_task(_download())
    return {"status": "started"}

@app.get("/video/play/{channel_id}/{msg_id}")
async def video_play(channel_id: str, msg_id: int, request: Request, token: str = ""):
    """Cache'den video sun. Henuz hazir degilse 404."""
    token       = _token_from(request, token)
    client, uid = await _client(token)
    key         = f"{uid}_{channel_id}_{msg_id}"
    cache_dir   = Path("cache/videos")
    for ext in [".mp4",".mkv",".mov",".avi",".webm",".orig",".jpg"]:
        p = cache_dir / f"{key}{ext}"
        if p.exists() and p.stat().st_size > 0:
            mime, _ = mimetypes.guess_type(str(p))
            return FileResponse(str(p), media_type=mime or "video/mp4",
                headers={"Accept-Ranges":"bytes","Cache-Control":"no-cache"})
    raise HTTPException(404, "Video henuz cache'de yok. Once /video/cache ile indirin.")


@app.get("/download/{channel_id}/{msg_id}")
async def download(channel_id: str, msg_id: int, request: Request, token: str = ""):
    token  = _token_from(request, token)
    client, uid = await _client(token)
    entity = "me" if channel_id == "me" else int(channel_id)

    msg = await client.get_messages(entity, ids=msg_id)
    if not msg or not msg.media:
        raise HTTPException(404, "Medya bulunamadi")

    from telethon.tl.types import MessageMediaPhoto, MessageMediaDocument
    if isinstance(msg.media, MessageMediaDocument):
        doc      = msg.media.document
        mime     = doc.mime_type or "application/octet-stream"
        filename = f"file_{msg_id}"
        for attr in doc.attributes:
            from telethon.tl.types import DocumentAttributeFilename
            if isinstance(attr, DocumentAttributeFilename):
                filename = attr.file_name
                break
    else:
        mime     = "image/jpeg"
        filename = f"photo_{msg_id}.jpg"

    data = await client.download_media(msg, bytes)
    if not data:
        raise HTTPException(500, "Indirme basarisiz")

    import urllib.parse
    safe = urllib.parse.quote(filename)
    return Response(content=data, media_type=mime,
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{safe}",
                 "Content-Length": str(len(data))})

# ── Yükleme ───────────────────────────────────────────────────────────────────

@app.post("/upload")
async def upload(request: Request):
    token      = _token_from(request)
    client, uid = await _client(token)
    form       = await request.form()
    file       = form.get("file")
    channel_id = form.get("channel_id", "me")

    if not file:
        raise HTTPException(400, "Dosya bulunamadi")

    filename = Path(file.filename or "upload.bin").name
    mime, _  = mimetypes.guess_type(filename)
    mime     = mime or "application/octet-stream"
    entity   = "me" if channel_id == "me" else int(channel_id)
    tmp      = Path("data") / f"tmp_{secrets.token_hex(6)}_{filename}"
    size     = 0

    try:
        with open(tmp, "wb") as out:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                out.write(chunk)

        msg = await client.send_file(
            entity, str(tmp), caption=filename,
            force_document=not mime.startswith(("image/","video/","audio/")),
        )
    finally:
        if tmp.exists(): tmp.unlink()

    # Upload sonrasi kanal cache'ini sifirla - yeni dosya aninda gorsunsun
    meta_file = _meta_path(uid, str(channel_id))
    if meta_file.exists():
        meta_file.unlink()
    logger.info("Kanal cache sifirlandi: %s", channel_id)

    return {"id": msg.id, "filename": filename, "size": size}

# ── Sistem ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {
        "status": "ok",
        "active_video_downloads": len(_video_downloads),
    }

@app.get("/system/cache/status")
async def cache_status(request: Request):
    client, uid = await _client(_token_from(request))
    return _cache_summary()

@app.post("/system/cache/cleanup")
async def cache_cleanup(body: CacheCleanupIn, request: Request):
    client, uid = await _client(_token_from(request))
    results = {}

    if body.thumbnails:
        thumb_dir = CACHE_DIRS["thumbnails"]
        thumb_files = []
        if thumb_dir.exists():
            thumb_files = list(thumb_dir.glob(f"{uid}_*")) + list(thumb_dir.glob(f".tmp_{uid}_*"))
        results["thumbnails"] = _cleanup_files(
            thumb_files,
            body.older_than_days,
        )

    if body.videos:
        video_dir = CACHE_DIRS["videos"]
        video_files = []
        if video_dir.exists():
            video_files = list(video_dir.glob(f"{uid}_*")) + list(video_dir.glob(f".tmp_{uid}_*"))
        results["videos"] = _cleanup_files(
            video_files,
            body.older_than_days,
        )

    if body.metadata:
        data_dir = Path("data")
        results["metadata"] = _cleanup_files(
            list(data_dir.glob(f"meta_{uid}_*.json")) if data_dir.exists() else [],
            body.older_than_days,
        )

    return {"status": "ok", "cleanup": results, "cache": _cache_summary()}

# Frontend serve (build varsa)
_dist = Path(__file__).parent.parent / "frontend" / "dist"

@app.get("/")
async def root():
    idx = _dist / "index.html"
    if idx.exists():
        return HTMLResponse(idx.read_text(encoding="utf-8"))
    return HTMLResponse("<h1>Frontend build edilmemis. setup.bat calistir.</h1>")

if (_dist / "assets").exists():
    app.mount("/assets", StaticFiles(directory=str(_dist / "assets")), name="assets")
